gdjs.Level_3211Code = {};
gdjs.Level_3211Code.GDleftWallObjects1= [];
gdjs.Level_3211Code.GDleftWallObjects2= [];
gdjs.Level_3211Code.GDrightWallObjects1= [];
gdjs.Level_3211Code.GDrightWallObjects2= [];
gdjs.Level_3211Code.GDbottomObjects1= [];
gdjs.Level_3211Code.GDbottomObjects2= [];
gdjs.Level_3211Code.GDBallObjects1= [];
gdjs.Level_3211Code.GDBallObjects2= [];
gdjs.Level_3211Code.GDspawnBallObjects1= [];
gdjs.Level_3211Code.GDspawnBallObjects2= [];
gdjs.Level_3211Code.GDGravityObjects1= [];
gdjs.Level_3211Code.GDGravityObjects2= [];
gdjs.Level_3211Code.GDmusicObjects1= [];
gdjs.Level_3211Code.GDmusicObjects2= [];
gdjs.Level_3211Code.GDgravityTextObjects1= [];
gdjs.Level_3211Code.GDgravityTextObjects2= [];
gdjs.Level_3211Code.GDfpsObjects1= [];
gdjs.Level_3211Code.GDfpsObjects2= [];
gdjs.Level_3211Code.GDpauseObjects1= [];
gdjs.Level_3211Code.GDpauseObjects2= [];
gdjs.Level_3211Code.GDPauseBackgroundObjects1= [];
gdjs.Level_3211Code.GDPauseBackgroundObjects2= [];
gdjs.Level_3211Code.GDPausedTextObjects1= [];
gdjs.Level_3211Code.GDPausedTextObjects2= [];
gdjs.Level_3211Code.GDexitToMainMenuObjects1= [];
gdjs.Level_3211Code.GDexitToMainMenuObjects2= [];
gdjs.Level_3211Code.GDRestartObjects1= [];
gdjs.Level_3211Code.GDRestartObjects2= [];
gdjs.Level_3211Code.GDGreenObjects1= [];
gdjs.Level_3211Code.GDGreenObjects2= [];
gdjs.Level_3211Code.GDballsObjects1= [];
gdjs.Level_3211Code.GDballsObjects2= [];
gdjs.Level_3211Code.GDNewTextObjects1= [];
gdjs.Level_3211Code.GDNewTextObjects2= [];

gdjs.Level_3211Code.conditionTrue_0 = {val:false};
gdjs.Level_3211Code.condition0IsTrue_0 = {val:false};
gdjs.Level_3211Code.condition1IsTrue_0 = {val:false};
gdjs.Level_3211Code.condition2IsTrue_0 = {val:false};
gdjs.Level_3211Code.condition3IsTrue_0 = {val:false};


gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDspawnBallObjects1Objects = Hashtable.newFrom({"spawnBall": gdjs.Level_3211Code.GDspawnBallObjects1});
gdjs.Level_3211Code.asyncCallback9077508 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_3211Code.GDspawnBallObjects2);
{for(var i = 0, len = gdjs.Level_3211Code.GDspawnBallObjects2.length ;i < len;++i) {
    gdjs.Level_3211Code.GDspawnBallObjects2[i].activateBehavior("Physics2", true);
}
}{gdjs.evtsExt__DiscordRichPresence__UpdateRichPresence.func(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), "Hit somthing game", 0, 0, "", "", "", "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.window.setWindowTitle(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene) + " - Hit something");
}{runtimeScene.getScene().getVariables().get("BallsLeft").setNumber(40);
}}
gdjs.Level_3211Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_3211Code.asyncCallback9077508(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDpauseObjects1Objects = Hashtable.newFrom({"pause": gdjs.Level_3211Code.GDpauseObjects1});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDPauseBackgroundObjects1Objects = Hashtable.newFrom({"PauseBackground": gdjs.Level_3211Code.GDPauseBackgroundObjects1});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDPausedTextObjects1Objects = Hashtable.newFrom({"PausedText": gdjs.Level_3211Code.GDPausedTextObjects1});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDexitToMainMenuObjects1Objects = Hashtable.newFrom({"exitToMainMenu": gdjs.Level_3211Code.GDexitToMainMenuObjects1});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDRestartObjects1Objects = Hashtable.newFrom({"Restart": gdjs.Level_3211Code.GDRestartObjects1});
gdjs.Level_3211Code.asyncCallback10258076 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
gdjs.Level_3211Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_3211Code.asyncCallback10258076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_3211Code.asyncCallback10263084 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
gdjs.Level_3211Code.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_3211Code.asyncCallback10263084(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDleftWallObjects1Objects = Hashtable.newFrom({"leftWall": gdjs.Level_3211Code.GDleftWallObjects1});
gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.Level_3211Code.GDBallObjects1});
gdjs.Level_3211Code.eventsList3 = function(runtimeScene) {

{


gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
gdjs.Level_3211Code.condition2IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if ( gdjs.Level_3211Code.condition1IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("BallsLeft")) > 0;
}}
}
if (gdjs.Level_3211Code.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("balls"), gdjs.Level_3211Code.GDballsObjects1);
gdjs.Level_3211Code.GDspawnBallObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDspawnBallObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}{runtimeScene.getScene().getVariables().get("BallsLeft").sub(1);
}{for(var i = 0, len = gdjs.Level_3211Code.GDballsObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDballsObjects1[i].setString("Balls left: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("BallsLeft"))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gravity"), gdjs.Level_3211Code.GDGravityObjects1);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDGravityObjects1.length;i<l;++i) {
    if ( !(gdjs.Level_3211Code.GDGravityObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDGravityObjects1[k] = gdjs.Level_3211Code.GDGravityObjects1[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDGravityObjects1.length = k;}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_3211Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_3211Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_3211Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDspawnBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gravity"), gdjs.Level_3211Code.GDGravityObjects1);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDGravityObjects1.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDGravityObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDGravityObjects1[k] = gdjs.Level_3211Code.GDGravityObjects1[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDGravityObjects1.length = k;}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_3211Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_3211Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_3211Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDspawnBallObjects1[i].activateBehavior("Physics2", true);
}
}}

}


{


gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_3211Code.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
gdjs.Level_3211Code.GDpauseObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDpauseObjects1Objects, 1824, 18, "");
}{for(var i = 0, len = gdjs.Level_3211Code.GDpauseObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDpauseObjects1[i].setScale(5);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.Level_3211Code.GDpauseObjects1);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDpauseObjects1.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDpauseObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDpauseObjects1[k] = gdjs.Level_3211Code.GDpauseObjects1[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDpauseObjects1.length = k;}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_3211Code.condition1IsTrue_0.val) {
gdjs.Level_3211Code.GDPauseBackgroundObjects1.length = 0;

gdjs.Level_3211Code.GDPausedTextObjects1.length = 0;

gdjs.Level_3211Code.GDRestartObjects1.length = 0;

gdjs.Level_3211Code.GDexitToMainMenuObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDPauseBackgroundObjects1Objects, 548, 106, "");
}{for(var i = 0, len = gdjs.Level_3211Code.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDPauseBackgroundObjects1[i].setHeight(805);
}
}{for(var i = 0, len = gdjs.Level_3211Code.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDPauseBackgroundObjects1[i].setWidth(797);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDPausedTextObjects1Objects, 777, 187, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDexitToMainMenuObjects1Objects, 726, 678, "");
}{for(var i = 0, len = gdjs.Level_3211Code.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDexitToMainMenuObjects1[i].setHeight(158);
}
}{for(var i = 0, len = gdjs.Level_3211Code.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDexitToMainMenuObjects1[i].setWidth(418);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDRestartObjects1Objects, 748, 316, "");
}{for(var i = 0, len = gdjs.Level_3211Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDRestartObjects1[i].setHeight(182);
}
}{for(var i = 0, len = gdjs.Level_3211Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDRestartObjects1[i].setWidth(376);
}
}
{ //Subevents
gdjs.Level_3211Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("exitToMainMenu"), gdjs.Level_3211Code.GDexitToMainMenuObjects1);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDexitToMainMenuObjects1.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDexitToMainMenuObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDexitToMainMenuObjects1[k] = gdjs.Level_3211Code.GDexitToMainMenuObjects1[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDexitToMainMenuObjects1.length = k;}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Start menu");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Level_3211Code.GDRestartObjects1);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDRestartObjects1.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDRestartObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDRestartObjects1[k] = gdjs.Level_3211Code.GDRestartObjects1[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDRestartObjects1.length = k;}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene));
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{


gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_3211Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_3211Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_3211Code.GDBallObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBallObjects1[i].activateBehavior("Physics2", false);
}
}{for(var i = 0, len = gdjs.Level_3211Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDspawnBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{


gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_3211Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_3211Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_3211Code.GDBallObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDBallObjects1[i].activateBehavior("Physics2", true);
}
}{for(var i = 0, len = gdjs.Level_3211Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDspawnBallObjects1[i].activateBehavior("Physics2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.Level_3211Code.GDpauseObjects1);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
gdjs.Level_3211Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_3211Code.GDpauseObjects1.length;i<l;++i) {
    if ( gdjs.Level_3211Code.GDpauseObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_3211Code.condition0IsTrue_0.val = true;
        gdjs.Level_3211Code.GDpauseObjects1[k] = gdjs.Level_3211Code.GDpauseObjects1[i];
        ++k;
    }
}
gdjs.Level_3211Code.GDpauseObjects1.length = k;}if ( gdjs.Level_3211Code.condition0IsTrue_0.val ) {
{
gdjs.Level_3211Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
if (gdjs.Level_3211Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PauseBackground"), gdjs.Level_3211Code.GDPauseBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("PausedText"), gdjs.Level_3211Code.GDPausedTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Level_3211Code.GDRestartObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitToMainMenu"), gdjs.Level_3211Code.GDexitToMainMenuObjects1);
{for(var i = 0, len = gdjs.Level_3211Code.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDPauseBackgroundObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_3211Code.GDPausedTextObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDPausedTextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_3211Code.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDexitToMainMenuObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_3211Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level_3211Code.GDRestartObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level_3211Code.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_3211Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("leftWall"), gdjs.Level_3211Code.GDleftWallObjects1);

gdjs.Level_3211Code.condition0IsTrue_0.val = false;
{
gdjs.Level_3211Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDleftWallObjects1Objects, "Physics2", gdjs.Level_3211Code.mapOfGDgdjs_46Level_953211Code_46GDBallObjects1Objects, false);
}if (gdjs.Level_3211Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Won");
}}

}


};

gdjs.Level_3211Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_3211Code.GDleftWallObjects1.length = 0;
gdjs.Level_3211Code.GDleftWallObjects2.length = 0;
gdjs.Level_3211Code.GDrightWallObjects1.length = 0;
gdjs.Level_3211Code.GDrightWallObjects2.length = 0;
gdjs.Level_3211Code.GDbottomObjects1.length = 0;
gdjs.Level_3211Code.GDbottomObjects2.length = 0;
gdjs.Level_3211Code.GDBallObjects1.length = 0;
gdjs.Level_3211Code.GDBallObjects2.length = 0;
gdjs.Level_3211Code.GDspawnBallObjects1.length = 0;
gdjs.Level_3211Code.GDspawnBallObjects2.length = 0;
gdjs.Level_3211Code.GDGravityObjects1.length = 0;
gdjs.Level_3211Code.GDGravityObjects2.length = 0;
gdjs.Level_3211Code.GDmusicObjects1.length = 0;
gdjs.Level_3211Code.GDmusicObjects2.length = 0;
gdjs.Level_3211Code.GDgravityTextObjects1.length = 0;
gdjs.Level_3211Code.GDgravityTextObjects2.length = 0;
gdjs.Level_3211Code.GDfpsObjects1.length = 0;
gdjs.Level_3211Code.GDfpsObjects2.length = 0;
gdjs.Level_3211Code.GDpauseObjects1.length = 0;
gdjs.Level_3211Code.GDpauseObjects2.length = 0;
gdjs.Level_3211Code.GDPauseBackgroundObjects1.length = 0;
gdjs.Level_3211Code.GDPauseBackgroundObjects2.length = 0;
gdjs.Level_3211Code.GDPausedTextObjects1.length = 0;
gdjs.Level_3211Code.GDPausedTextObjects2.length = 0;
gdjs.Level_3211Code.GDexitToMainMenuObjects1.length = 0;
gdjs.Level_3211Code.GDexitToMainMenuObjects2.length = 0;
gdjs.Level_3211Code.GDRestartObjects1.length = 0;
gdjs.Level_3211Code.GDRestartObjects2.length = 0;
gdjs.Level_3211Code.GDGreenObjects1.length = 0;
gdjs.Level_3211Code.GDGreenObjects2.length = 0;
gdjs.Level_3211Code.GDballsObjects1.length = 0;
gdjs.Level_3211Code.GDballsObjects2.length = 0;
gdjs.Level_3211Code.GDNewTextObjects1.length = 0;
gdjs.Level_3211Code.GDNewTextObjects2.length = 0;

gdjs.Level_3211Code.eventsList3(runtimeScene);

return;

}

gdjs['Level_3211Code'] = gdjs.Level_3211Code;
