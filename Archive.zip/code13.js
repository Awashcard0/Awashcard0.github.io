gdjs.WonCode = {};
gdjs.WonCode.GDleftWallObjects1= [];
gdjs.WonCode.GDleftWallObjects2= [];
gdjs.WonCode.GDrightWallObjects1= [];
gdjs.WonCode.GDrightWallObjects2= [];
gdjs.WonCode.GDbottomObjects1= [];
gdjs.WonCode.GDbottomObjects2= [];
gdjs.WonCode.GDBallObjects1= [];
gdjs.WonCode.GDBallObjects2= [];
gdjs.WonCode.GDspawnBallObjects1= [];
gdjs.WonCode.GDspawnBallObjects2= [];
gdjs.WonCode.GDGravityObjects1= [];
gdjs.WonCode.GDGravityObjects2= [];
gdjs.WonCode.GDmusicObjects1= [];
gdjs.WonCode.GDmusicObjects2= [];
gdjs.WonCode.GDgravityTextObjects1= [];
gdjs.WonCode.GDgravityTextObjects2= [];
gdjs.WonCode.GDfpsObjects1= [];
gdjs.WonCode.GDfpsObjects2= [];
gdjs.WonCode.GDpauseObjects1= [];
gdjs.WonCode.GDpauseObjects2= [];
gdjs.WonCode.GDPauseBackgroundObjects1= [];
gdjs.WonCode.GDPauseBackgroundObjects2= [];
gdjs.WonCode.GDPausedTextObjects1= [];
gdjs.WonCode.GDPausedTextObjects2= [];
gdjs.WonCode.GDexitToMainMenuObjects1= [];
gdjs.WonCode.GDexitToMainMenuObjects2= [];
gdjs.WonCode.GDRestartObjects1= [];
gdjs.WonCode.GDRestartObjects2= [];
gdjs.WonCode.GDGreenObjects1= [];
gdjs.WonCode.GDGreenObjects2= [];
gdjs.WonCode.GDNewTextObjects1= [];
gdjs.WonCode.GDNewTextObjects2= [];
gdjs.WonCode.GDBlueButtonObjects1= [];
gdjs.WonCode.GDBlueButtonObjects2= [];
gdjs.WonCode.GDtimeObjects1= [];
gdjs.WonCode.GDtimeObjects2= [];

gdjs.WonCode.conditionTrue_0 = {val:false};
gdjs.WonCode.condition0IsTrue_0 = {val:false};
gdjs.WonCode.condition1IsTrue_0 = {val:false};
gdjs.WonCode.condition2IsTrue_0 = {val:false};


gdjs.WonCode.asyncCallback10245652 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.WonCode.GDspawnBallObjects2);
gdjs.copyArray(runtimeScene.getObjects("time"), gdjs.WonCode.GDtimeObjects2);
{for(var i = 0, len = gdjs.WonCode.GDspawnBallObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDspawnBallObjects2[i].activateBehavior("Physics2", true);
}
}{gdjs.evtsExt__DiscordRichPresence__UpdateRichPresence.func(runtimeScene, "Hit somthing", "On the win screen", 0, 0, "", "", "", "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.window.setWindowTitle(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene) + " - Hit something");
}{for(var i = 0, len = gdjs.WonCode.GDtimeObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDtimeObjects2[i].setString("Balls used: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2))));
}
}}
gdjs.WonCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.WonCode.asyncCallback10245652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.WonCode.mapOfGDgdjs_46WonCode_46GDpauseObjects1Objects = Hashtable.newFrom({"pause": gdjs.WonCode.GDpauseObjects1});
gdjs.WonCode.mapOfGDgdjs_46WonCode_46GDPauseBackgroundObjects1Objects = Hashtable.newFrom({"PauseBackground": gdjs.WonCode.GDPauseBackgroundObjects1});
gdjs.WonCode.mapOfGDgdjs_46WonCode_46GDPausedTextObjects1Objects = Hashtable.newFrom({"PausedText": gdjs.WonCode.GDPausedTextObjects1});
gdjs.WonCode.mapOfGDgdjs_46WonCode_46GDexitToMainMenuObjects1Objects = Hashtable.newFrom({"exitToMainMenu": gdjs.WonCode.GDexitToMainMenuObjects1});
gdjs.WonCode.mapOfGDgdjs_46WonCode_46GDRestartObjects1Objects = Hashtable.newFrom({"Restart": gdjs.WonCode.GDRestartObjects1});
gdjs.WonCode.asyncCallback10258076 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
gdjs.WonCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.WonCode.asyncCallback10258076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.WonCode.asyncCallback10263084 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
gdjs.WonCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.WonCode.asyncCallback10263084(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.WonCode.mapOfGDgdjs_46WonCode_46GDspawnBallObjects1Objects = Hashtable.newFrom({"spawnBall": gdjs.WonCode.GDspawnBallObjects1});
gdjs.WonCode.eventsList3 = function(runtimeScene) {

{


gdjs.WonCode.condition0IsTrue_0.val = false;
{
gdjs.WonCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.WonCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.WonCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueButton"), gdjs.WonCode.GDBlueButtonObjects1);

gdjs.WonCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.WonCode.GDBlueButtonObjects1.length;i<l;++i) {
    if ( gdjs.WonCode.GDBlueButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.WonCode.condition0IsTrue_0.val = true;
        gdjs.WonCode.GDBlueButtonObjects1[k] = gdjs.WonCode.GDBlueButtonObjects1[i];
        ++k;
    }
}
gdjs.WonCode.GDBlueButtonObjects1.length = k;}if (gdjs.WonCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Start menu");
}}

}


{



}


{


gdjs.WonCode.condition0IsTrue_0.val = false;
{
gdjs.WonCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.WonCode.condition0IsTrue_0.val) {
gdjs.WonCode.GDpauseObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WonCode.mapOfGDgdjs_46WonCode_46GDpauseObjects1Objects, 1824, 18, "");
}{for(var i = 0, len = gdjs.WonCode.GDpauseObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDpauseObjects1[i].setScale(5);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.WonCode.GDpauseObjects1);

gdjs.WonCode.condition0IsTrue_0.val = false;
gdjs.WonCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.WonCode.GDpauseObjects1.length;i<l;++i) {
    if ( gdjs.WonCode.GDpauseObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.WonCode.condition0IsTrue_0.val = true;
        gdjs.WonCode.GDpauseObjects1[k] = gdjs.WonCode.GDpauseObjects1[i];
        ++k;
    }
}
gdjs.WonCode.GDpauseObjects1.length = k;}if ( gdjs.WonCode.condition0IsTrue_0.val ) {
{
gdjs.WonCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.WonCode.condition1IsTrue_0.val) {
gdjs.WonCode.GDPauseBackgroundObjects1.length = 0;

gdjs.WonCode.GDPausedTextObjects1.length = 0;

gdjs.WonCode.GDRestartObjects1.length = 0;

gdjs.WonCode.GDexitToMainMenuObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WonCode.mapOfGDgdjs_46WonCode_46GDPauseBackgroundObjects1Objects, 548, 106, "");
}{for(var i = 0, len = gdjs.WonCode.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDPauseBackgroundObjects1[i].setHeight(805);
}
}{for(var i = 0, len = gdjs.WonCode.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDPauseBackgroundObjects1[i].setWidth(797);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WonCode.mapOfGDgdjs_46WonCode_46GDPausedTextObjects1Objects, 777, 187, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WonCode.mapOfGDgdjs_46WonCode_46GDexitToMainMenuObjects1Objects, 726, 678, "");
}{for(var i = 0, len = gdjs.WonCode.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDexitToMainMenuObjects1[i].setHeight(158);
}
}{for(var i = 0, len = gdjs.WonCode.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDexitToMainMenuObjects1[i].setWidth(418);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WonCode.mapOfGDgdjs_46WonCode_46GDRestartObjects1Objects, 748, 316, "");
}{for(var i = 0, len = gdjs.WonCode.GDRestartObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDRestartObjects1[i].setHeight(182);
}
}{for(var i = 0, len = gdjs.WonCode.GDRestartObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDRestartObjects1[i].setWidth(376);
}
}
{ //Subevents
gdjs.WonCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("exitToMainMenu"), gdjs.WonCode.GDexitToMainMenuObjects1);

gdjs.WonCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.WonCode.GDexitToMainMenuObjects1.length;i<l;++i) {
    if ( gdjs.WonCode.GDexitToMainMenuObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.WonCode.condition0IsTrue_0.val = true;
        gdjs.WonCode.GDexitToMainMenuObjects1[k] = gdjs.WonCode.GDexitToMainMenuObjects1[i];
        ++k;
    }
}
gdjs.WonCode.GDexitToMainMenuObjects1.length = k;}if (gdjs.WonCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Start menu");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.WonCode.GDRestartObjects1);

gdjs.WonCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.WonCode.GDRestartObjects1.length;i<l;++i) {
    if ( gdjs.WonCode.GDRestartObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.WonCode.condition0IsTrue_0.val = true;
        gdjs.WonCode.GDRestartObjects1[k] = gdjs.WonCode.GDRestartObjects1[i];
        ++k;
    }
}
gdjs.WonCode.GDRestartObjects1.length = k;}if (gdjs.WonCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene));
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{


gdjs.WonCode.condition0IsTrue_0.val = false;
{
gdjs.WonCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if (gdjs.WonCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.WonCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.WonCode.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.WonCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDBallObjects1[i].activateBehavior("Physics2", false);
}
}{for(var i = 0, len = gdjs.WonCode.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDspawnBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{


gdjs.WonCode.condition0IsTrue_0.val = false;
{
gdjs.WonCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if (gdjs.WonCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.WonCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.WonCode.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.WonCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDBallObjects1[i].activateBehavior("Physics2", true);
}
}{for(var i = 0, len = gdjs.WonCode.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDspawnBallObjects1[i].activateBehavior("Physics2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.WonCode.GDpauseObjects1);

gdjs.WonCode.condition0IsTrue_0.val = false;
gdjs.WonCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.WonCode.GDpauseObjects1.length;i<l;++i) {
    if ( gdjs.WonCode.GDpauseObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.WonCode.condition0IsTrue_0.val = true;
        gdjs.WonCode.GDpauseObjects1[k] = gdjs.WonCode.GDpauseObjects1[i];
        ++k;
    }
}
gdjs.WonCode.GDpauseObjects1.length = k;}if ( gdjs.WonCode.condition0IsTrue_0.val ) {
{
gdjs.WonCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
if (gdjs.WonCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PauseBackground"), gdjs.WonCode.GDPauseBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("PausedText"), gdjs.WonCode.GDPausedTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.WonCode.GDRestartObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitToMainMenu"), gdjs.WonCode.GDexitToMainMenuObjects1);
{for(var i = 0, len = gdjs.WonCode.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDPauseBackgroundObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WonCode.GDPausedTextObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDPausedTextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WonCode.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDexitToMainMenuObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.WonCode.GDRestartObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDRestartObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.WonCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Gravity"), gdjs.WonCode.GDGravityObjects1);

gdjs.WonCode.condition0IsTrue_0.val = false;
gdjs.WonCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.WonCode.GDGravityObjects1.length;i<l;++i) {
    if ( gdjs.WonCode.GDGravityObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.WonCode.condition0IsTrue_0.val = true;
        gdjs.WonCode.GDGravityObjects1[k] = gdjs.WonCode.GDGravityObjects1[i];
        ++k;
    }
}
gdjs.WonCode.GDGravityObjects1.length = k;}if ( gdjs.WonCode.condition0IsTrue_0.val ) {
{
gdjs.WonCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.WonCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.WonCode.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.WonCode.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDspawnBallObjects1[i].activateBehavior("Physics2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gravity"), gdjs.WonCode.GDGravityObjects1);

gdjs.WonCode.condition0IsTrue_0.val = false;
gdjs.WonCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.WonCode.GDGravityObjects1.length;i<l;++i) {
    if ( !(gdjs.WonCode.GDGravityObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.WonCode.condition0IsTrue_0.val = true;
        gdjs.WonCode.GDGravityObjects1[k] = gdjs.WonCode.GDGravityObjects1[i];
        ++k;
    }
}
gdjs.WonCode.GDGravityObjects1.length = k;}if ( gdjs.WonCode.condition0IsTrue_0.val ) {
{
gdjs.WonCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.WonCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.WonCode.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.WonCode.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDspawnBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{


gdjs.WonCode.condition0IsTrue_0.val = false;
gdjs.WonCode.condition1IsTrue_0.val = false;
{
gdjs.WonCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.WonCode.condition0IsTrue_0.val ) {
{
gdjs.WonCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.WonCode.condition1IsTrue_0.val) {
gdjs.WonCode.GDspawnBallObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.WonCode.mapOfGDgdjs_46WonCode_46GDspawnBallObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}}

}


{


{
}

}


};

gdjs.WonCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.WonCode.GDleftWallObjects1.length = 0;
gdjs.WonCode.GDleftWallObjects2.length = 0;
gdjs.WonCode.GDrightWallObjects1.length = 0;
gdjs.WonCode.GDrightWallObjects2.length = 0;
gdjs.WonCode.GDbottomObjects1.length = 0;
gdjs.WonCode.GDbottomObjects2.length = 0;
gdjs.WonCode.GDBallObjects1.length = 0;
gdjs.WonCode.GDBallObjects2.length = 0;
gdjs.WonCode.GDspawnBallObjects1.length = 0;
gdjs.WonCode.GDspawnBallObjects2.length = 0;
gdjs.WonCode.GDGravityObjects1.length = 0;
gdjs.WonCode.GDGravityObjects2.length = 0;
gdjs.WonCode.GDmusicObjects1.length = 0;
gdjs.WonCode.GDmusicObjects2.length = 0;
gdjs.WonCode.GDgravityTextObjects1.length = 0;
gdjs.WonCode.GDgravityTextObjects2.length = 0;
gdjs.WonCode.GDfpsObjects1.length = 0;
gdjs.WonCode.GDfpsObjects2.length = 0;
gdjs.WonCode.GDpauseObjects1.length = 0;
gdjs.WonCode.GDpauseObjects2.length = 0;
gdjs.WonCode.GDPauseBackgroundObjects1.length = 0;
gdjs.WonCode.GDPauseBackgroundObjects2.length = 0;
gdjs.WonCode.GDPausedTextObjects1.length = 0;
gdjs.WonCode.GDPausedTextObjects2.length = 0;
gdjs.WonCode.GDexitToMainMenuObjects1.length = 0;
gdjs.WonCode.GDexitToMainMenuObjects2.length = 0;
gdjs.WonCode.GDRestartObjects1.length = 0;
gdjs.WonCode.GDRestartObjects2.length = 0;
gdjs.WonCode.GDGreenObjects1.length = 0;
gdjs.WonCode.GDGreenObjects2.length = 0;
gdjs.WonCode.GDNewTextObjects1.length = 0;
gdjs.WonCode.GDNewTextObjects2.length = 0;
gdjs.WonCode.GDBlueButtonObjects1.length = 0;
gdjs.WonCode.GDBlueButtonObjects2.length = 0;
gdjs.WonCode.GDtimeObjects1.length = 0;
gdjs.WonCode.GDtimeObjects2.length = 0;

gdjs.WonCode.eventsList3(runtimeScene);

return;

}

gdjs['WonCode'] = gdjs.WonCode;
