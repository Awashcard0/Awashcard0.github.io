gdjs.LoadingCode = {};
gdjs.LoadingCode.GDleftWallObjects1= [];
gdjs.LoadingCode.GDleftWallObjects2= [];
gdjs.LoadingCode.GDleftWallObjects3= [];
gdjs.LoadingCode.GDleftWallObjects4= [];
gdjs.LoadingCode.GDrightWallObjects1= [];
gdjs.LoadingCode.GDrightWallObjects2= [];
gdjs.LoadingCode.GDrightWallObjects3= [];
gdjs.LoadingCode.GDrightWallObjects4= [];
gdjs.LoadingCode.GDbottomObjects1= [];
gdjs.LoadingCode.GDbottomObjects2= [];
gdjs.LoadingCode.GDbottomObjects3= [];
gdjs.LoadingCode.GDbottomObjects4= [];
gdjs.LoadingCode.GDBallObjects1= [];
gdjs.LoadingCode.GDBallObjects2= [];
gdjs.LoadingCode.GDBallObjects3= [];
gdjs.LoadingCode.GDBallObjects4= [];
gdjs.LoadingCode.GDspawnBallObjects1= [];
gdjs.LoadingCode.GDspawnBallObjects2= [];
gdjs.LoadingCode.GDspawnBallObjects3= [];
gdjs.LoadingCode.GDspawnBallObjects4= [];
gdjs.LoadingCode.GDGravityObjects1= [];
gdjs.LoadingCode.GDGravityObjects2= [];
gdjs.LoadingCode.GDGravityObjects3= [];
gdjs.LoadingCode.GDGravityObjects4= [];
gdjs.LoadingCode.GDmusicObjects1= [];
gdjs.LoadingCode.GDmusicObjects2= [];
gdjs.LoadingCode.GDmusicObjects3= [];
gdjs.LoadingCode.GDmusicObjects4= [];
gdjs.LoadingCode.GDgravityTextObjects1= [];
gdjs.LoadingCode.GDgravityTextObjects2= [];
gdjs.LoadingCode.GDgravityTextObjects3= [];
gdjs.LoadingCode.GDgravityTextObjects4= [];
gdjs.LoadingCode.GDfpsObjects1= [];
gdjs.LoadingCode.GDfpsObjects2= [];
gdjs.LoadingCode.GDfpsObjects3= [];
gdjs.LoadingCode.GDfpsObjects4= [];
gdjs.LoadingCode.GDpauseObjects1= [];
gdjs.LoadingCode.GDpauseObjects2= [];
gdjs.LoadingCode.GDpauseObjects3= [];
gdjs.LoadingCode.GDpauseObjects4= [];
gdjs.LoadingCode.GDPauseBackgroundObjects1= [];
gdjs.LoadingCode.GDPauseBackgroundObjects2= [];
gdjs.LoadingCode.GDPauseBackgroundObjects3= [];
gdjs.LoadingCode.GDPauseBackgroundObjects4= [];
gdjs.LoadingCode.GDPausedTextObjects1= [];
gdjs.LoadingCode.GDPausedTextObjects2= [];
gdjs.LoadingCode.GDPausedTextObjects3= [];
gdjs.LoadingCode.GDPausedTextObjects4= [];
gdjs.LoadingCode.GDexitToMainMenuObjects1= [];
gdjs.LoadingCode.GDexitToMainMenuObjects2= [];
gdjs.LoadingCode.GDexitToMainMenuObjects3= [];
gdjs.LoadingCode.GDexitToMainMenuObjects4= [];
gdjs.LoadingCode.GDRestartObjects1= [];
gdjs.LoadingCode.GDRestartObjects2= [];
gdjs.LoadingCode.GDRestartObjects3= [];
gdjs.LoadingCode.GDRestartObjects4= [];
gdjs.LoadingCode.GDGreenObjects1= [];
gdjs.LoadingCode.GDGreenObjects2= [];
gdjs.LoadingCode.GDGreenObjects3= [];
gdjs.LoadingCode.GDGreenObjects4= [];
gdjs.LoadingCode.GDLoadingTextObjects1= [];
gdjs.LoadingCode.GDLoadingTextObjects2= [];
gdjs.LoadingCode.GDLoadingTextObjects3= [];
gdjs.LoadingCode.GDLoadingTextObjects4= [];
gdjs.LoadingCode.GDvertionObjects1= [];
gdjs.LoadingCode.GDvertionObjects2= [];
gdjs.LoadingCode.GDvertionObjects3= [];
gdjs.LoadingCode.GDvertionObjects4= [];
gdjs.LoadingCode.GDerrorObjects1= [];
gdjs.LoadingCode.GDerrorObjects2= [];
gdjs.LoadingCode.GDerrorObjects3= [];
gdjs.LoadingCode.GDerrorObjects4= [];

gdjs.LoadingCode.conditionTrue_0 = {val:false};
gdjs.LoadingCode.condition0IsTrue_0 = {val:false};
gdjs.LoadingCode.condition1IsTrue_0 = {val:false};


gdjs.LoadingCode.asyncCallback10145252 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Start menu");
}}
gdjs.LoadingCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.LoadingCode.asyncCallback10145252(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoadingCode.asyncCallback10143908 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("LoadingText"), gdjs.LoadingCode.GDLoadingTextObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("error"), gdjs.LoadingCode.GDerrorObjects3);

{for(var i = 0, len = gdjs.LoadingCode.GDerrorObjects3.length ;i < len;++i) {
    gdjs.LoadingCode.GDerrorObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.LoadingCode.GDLoadingTextObjects3.length ;i < len;++i) {
    gdjs.LoadingCode.GDLoadingTextObjects3[i].setString("Done");
}
}
{ //Subevents
gdjs.LoadingCode.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoadingCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.LoadingCode.GDLoadingTextObjects2) asyncObjectsList.addObject("LoadingText", obj);
for (const obj of gdjs.LoadingCode.GDerrorObjects2) asyncObjectsList.addObject("error", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.LoadingCode.asyncCallback10143908(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoadingCode.asyncCallback10144028 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("LoadingText"), gdjs.LoadingCode.GDLoadingTextObjects2);

gdjs.copyArray(runtimeScene.getObjects("error"), gdjs.LoadingCode.GDerrorObjects2);
{for(var i = 0, len = gdjs.LoadingCode.GDLoadingTextObjects2.length ;i < len;++i) {
    gdjs.LoadingCode.GDLoadingTextObjects2[i].setString("The newest version is " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.LoadingCode.GDerrorObjects2.length ;i < len;++i) {
    gdjs.LoadingCode.GDerrorObjects2[i].setString(gdjs.LoadingCode.GDerrorObjects2[i].getString() + (gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1))));
}
}
{ //Subevents
gdjs.LoadingCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.LoadingCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.LoadingCode.GDLoadingTextObjects1) asyncObjectsList.addObject("LoadingText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("https://awashcard0.pages.dev/games/hit-the-thing/v.txt", "", "GET", "", runtimeScene.getScene().getVariables().getFromIndex(0), runtimeScene.getScene().getVariables().getFromIndex(1)), (runtimeScene) => (gdjs.LoadingCode.asyncCallback10144028(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LoadingCode.eventsList3 = function(runtimeScene) {

{


gdjs.LoadingCode.condition0IsTrue_0.val = false;
{
gdjs.LoadingCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LoadingCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LoadingText"), gdjs.LoadingCode.GDLoadingTextObjects1);
{gdjs.evtTools.window.setWindowTitle(runtimeScene, "Loading...");
}{for(var i = 0, len = gdjs.LoadingCode.GDLoadingTextObjects1.length ;i < len;++i) {
    gdjs.LoadingCode.GDLoadingTextObjects1[i].setString("Checking for updates...");
}
}
{ //Subevents
gdjs.LoadingCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


{
}

}


};

gdjs.LoadingCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LoadingCode.GDleftWallObjects1.length = 0;
gdjs.LoadingCode.GDleftWallObjects2.length = 0;
gdjs.LoadingCode.GDleftWallObjects3.length = 0;
gdjs.LoadingCode.GDleftWallObjects4.length = 0;
gdjs.LoadingCode.GDrightWallObjects1.length = 0;
gdjs.LoadingCode.GDrightWallObjects2.length = 0;
gdjs.LoadingCode.GDrightWallObjects3.length = 0;
gdjs.LoadingCode.GDrightWallObjects4.length = 0;
gdjs.LoadingCode.GDbottomObjects1.length = 0;
gdjs.LoadingCode.GDbottomObjects2.length = 0;
gdjs.LoadingCode.GDbottomObjects3.length = 0;
gdjs.LoadingCode.GDbottomObjects4.length = 0;
gdjs.LoadingCode.GDBallObjects1.length = 0;
gdjs.LoadingCode.GDBallObjects2.length = 0;
gdjs.LoadingCode.GDBallObjects3.length = 0;
gdjs.LoadingCode.GDBallObjects4.length = 0;
gdjs.LoadingCode.GDspawnBallObjects1.length = 0;
gdjs.LoadingCode.GDspawnBallObjects2.length = 0;
gdjs.LoadingCode.GDspawnBallObjects3.length = 0;
gdjs.LoadingCode.GDspawnBallObjects4.length = 0;
gdjs.LoadingCode.GDGravityObjects1.length = 0;
gdjs.LoadingCode.GDGravityObjects2.length = 0;
gdjs.LoadingCode.GDGravityObjects3.length = 0;
gdjs.LoadingCode.GDGravityObjects4.length = 0;
gdjs.LoadingCode.GDmusicObjects1.length = 0;
gdjs.LoadingCode.GDmusicObjects2.length = 0;
gdjs.LoadingCode.GDmusicObjects3.length = 0;
gdjs.LoadingCode.GDmusicObjects4.length = 0;
gdjs.LoadingCode.GDgravityTextObjects1.length = 0;
gdjs.LoadingCode.GDgravityTextObjects2.length = 0;
gdjs.LoadingCode.GDgravityTextObjects3.length = 0;
gdjs.LoadingCode.GDgravityTextObjects4.length = 0;
gdjs.LoadingCode.GDfpsObjects1.length = 0;
gdjs.LoadingCode.GDfpsObjects2.length = 0;
gdjs.LoadingCode.GDfpsObjects3.length = 0;
gdjs.LoadingCode.GDfpsObjects4.length = 0;
gdjs.LoadingCode.GDpauseObjects1.length = 0;
gdjs.LoadingCode.GDpauseObjects2.length = 0;
gdjs.LoadingCode.GDpauseObjects3.length = 0;
gdjs.LoadingCode.GDpauseObjects4.length = 0;
gdjs.LoadingCode.GDPauseBackgroundObjects1.length = 0;
gdjs.LoadingCode.GDPauseBackgroundObjects2.length = 0;
gdjs.LoadingCode.GDPauseBackgroundObjects3.length = 0;
gdjs.LoadingCode.GDPauseBackgroundObjects4.length = 0;
gdjs.LoadingCode.GDPausedTextObjects1.length = 0;
gdjs.LoadingCode.GDPausedTextObjects2.length = 0;
gdjs.LoadingCode.GDPausedTextObjects3.length = 0;
gdjs.LoadingCode.GDPausedTextObjects4.length = 0;
gdjs.LoadingCode.GDexitToMainMenuObjects1.length = 0;
gdjs.LoadingCode.GDexitToMainMenuObjects2.length = 0;
gdjs.LoadingCode.GDexitToMainMenuObjects3.length = 0;
gdjs.LoadingCode.GDexitToMainMenuObjects4.length = 0;
gdjs.LoadingCode.GDRestartObjects1.length = 0;
gdjs.LoadingCode.GDRestartObjects2.length = 0;
gdjs.LoadingCode.GDRestartObjects3.length = 0;
gdjs.LoadingCode.GDRestartObjects4.length = 0;
gdjs.LoadingCode.GDGreenObjects1.length = 0;
gdjs.LoadingCode.GDGreenObjects2.length = 0;
gdjs.LoadingCode.GDGreenObjects3.length = 0;
gdjs.LoadingCode.GDGreenObjects4.length = 0;
gdjs.LoadingCode.GDLoadingTextObjects1.length = 0;
gdjs.LoadingCode.GDLoadingTextObjects2.length = 0;
gdjs.LoadingCode.GDLoadingTextObjects3.length = 0;
gdjs.LoadingCode.GDLoadingTextObjects4.length = 0;
gdjs.LoadingCode.GDvertionObjects1.length = 0;
gdjs.LoadingCode.GDvertionObjects2.length = 0;
gdjs.LoadingCode.GDvertionObjects3.length = 0;
gdjs.LoadingCode.GDvertionObjects4.length = 0;
gdjs.LoadingCode.GDerrorObjects1.length = 0;
gdjs.LoadingCode.GDerrorObjects2.length = 0;
gdjs.LoadingCode.GDerrorObjects3.length = 0;
gdjs.LoadingCode.GDerrorObjects4.length = 0;

gdjs.LoadingCode.eventsList3(runtimeScene);

return;

}

gdjs['LoadingCode'] = gdjs.LoadingCode;
