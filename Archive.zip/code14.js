gdjs.LevelCode = {};
gdjs.LevelCode.GDleftWallObjects1= [];
gdjs.LevelCode.GDleftWallObjects2= [];
gdjs.LevelCode.GDrightWallObjects1= [];
gdjs.LevelCode.GDrightWallObjects2= [];
gdjs.LevelCode.GDbottomObjects1= [];
gdjs.LevelCode.GDbottomObjects2= [];
gdjs.LevelCode.GDBallObjects1= [];
gdjs.LevelCode.GDBallObjects2= [];
gdjs.LevelCode.GDspawnBallObjects1= [];
gdjs.LevelCode.GDspawnBallObjects2= [];
gdjs.LevelCode.GDGravityObjects1= [];
gdjs.LevelCode.GDGravityObjects2= [];
gdjs.LevelCode.GDmusicObjects1= [];
gdjs.LevelCode.GDmusicObjects2= [];
gdjs.LevelCode.GDgravityTextObjects1= [];
gdjs.LevelCode.GDgravityTextObjects2= [];
gdjs.LevelCode.GDfpsObjects1= [];
gdjs.LevelCode.GDfpsObjects2= [];
gdjs.LevelCode.GDpauseObjects1= [];
gdjs.LevelCode.GDpauseObjects2= [];
gdjs.LevelCode.GDPauseBackgroundObjects1= [];
gdjs.LevelCode.GDPauseBackgroundObjects2= [];
gdjs.LevelCode.GDPausedTextObjects1= [];
gdjs.LevelCode.GDPausedTextObjects2= [];
gdjs.LevelCode.GDexitToMainMenuObjects1= [];
gdjs.LevelCode.GDexitToMainMenuObjects2= [];
gdjs.LevelCode.GDRestartObjects1= [];
gdjs.LevelCode.GDRestartObjects2= [];
gdjs.LevelCode.GDGreenObjects1= [];
gdjs.LevelCode.GDGreenObjects2= [];

gdjs.LevelCode.conditionTrue_0 = {val:false};
gdjs.LevelCode.condition0IsTrue_0 = {val:false};
gdjs.LevelCode.condition1IsTrue_0 = {val:false};
gdjs.LevelCode.condition2IsTrue_0 = {val:false};


gdjs.LevelCode.asyncCallback9269172 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.LevelCode.GDspawnBallObjects2);
{for(var i = 0, len = gdjs.LevelCode.GDspawnBallObjects2.length ;i < len;++i) {
    gdjs.LevelCode.GDspawnBallObjects2[i].activateBehavior("Physics2", true);
}
}{gdjs.evtsExt__DiscordRichPresence__UpdateRichPresence.func(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), "Hit somthing game", 0, 0, "", "", "", "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.window.setWindowTitle(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene) + " - Hit something");
}}
gdjs.LevelCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.LevelCode.asyncCallback9269172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDpauseObjects1Objects = Hashtable.newFrom({"pause": gdjs.LevelCode.GDpauseObjects1});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPauseBackgroundObjects1Objects = Hashtable.newFrom({"PauseBackground": gdjs.LevelCode.GDPauseBackgroundObjects1});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPausedTextObjects1Objects = Hashtable.newFrom({"PausedText": gdjs.LevelCode.GDPausedTextObjects1});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDexitToMainMenuObjects1Objects = Hashtable.newFrom({"exitToMainMenu": gdjs.LevelCode.GDexitToMainMenuObjects1});
gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDRestartObjects1Objects = Hashtable.newFrom({"Restart": gdjs.LevelCode.GDRestartObjects1});
gdjs.LevelCode.asyncCallback10258076 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
gdjs.LevelCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.LevelCode.asyncCallback10258076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LevelCode.asyncCallback10263084 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
gdjs.LevelCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.LevelCode.asyncCallback10263084(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDspawnBallObjects1Objects = Hashtable.newFrom({"spawnBall": gdjs.LevelCode.GDspawnBallObjects1});
gdjs.LevelCode.eventsList3 = function(runtimeScene) {

{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.LevelCode.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.LevelCode.GDpauseObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDpauseObjects1Objects, 1824, 18, "");
}{for(var i = 0, len = gdjs.LevelCode.GDpauseObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDpauseObjects1[i].setScale(5);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.LevelCode.GDpauseObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDpauseObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDpauseObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDpauseObjects1[k] = gdjs.LevelCode.GDpauseObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDpauseObjects1.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.LevelCode.GDPauseBackgroundObjects1.length = 0;

gdjs.LevelCode.GDPausedTextObjects1.length = 0;

gdjs.LevelCode.GDRestartObjects1.length = 0;

gdjs.LevelCode.GDexitToMainMenuObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPauseBackgroundObjects1Objects, 548, 106, "");
}{for(var i = 0, len = gdjs.LevelCode.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDPauseBackgroundObjects1[i].setHeight(805);
}
}{for(var i = 0, len = gdjs.LevelCode.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDPauseBackgroundObjects1[i].setWidth(797);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDPausedTextObjects1Objects, 777, 187, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDexitToMainMenuObjects1Objects, 726, 678, "");
}{for(var i = 0, len = gdjs.LevelCode.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDexitToMainMenuObjects1[i].setHeight(158);
}
}{for(var i = 0, len = gdjs.LevelCode.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDexitToMainMenuObjects1[i].setWidth(418);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDRestartObjects1Objects, 748, 316, "");
}{for(var i = 0, len = gdjs.LevelCode.GDRestartObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDRestartObjects1[i].setHeight(182);
}
}{for(var i = 0, len = gdjs.LevelCode.GDRestartObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDRestartObjects1[i].setWidth(376);
}
}
{ //Subevents
gdjs.LevelCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("exitToMainMenu"), gdjs.LevelCode.GDexitToMainMenuObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDexitToMainMenuObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDexitToMainMenuObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDexitToMainMenuObjects1[k] = gdjs.LevelCode.GDexitToMainMenuObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDexitToMainMenuObjects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Start menu");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.LevelCode.GDRestartObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDRestartObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDRestartObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDRestartObjects1[k] = gdjs.LevelCode.GDRestartObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDRestartObjects1.length = k;}if (gdjs.LevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene));
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.LevelCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.LevelCode.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.LevelCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDBallObjects1[i].activateBehavior("Physics2", false);
}
}{for(var i = 0, len = gdjs.LevelCode.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDspawnBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if (gdjs.LevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.LevelCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.LevelCode.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.LevelCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDBallObjects1[i].activateBehavior("Physics2", true);
}
}{for(var i = 0, len = gdjs.LevelCode.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDspawnBallObjects1[i].activateBehavior("Physics2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.LevelCode.GDpauseObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDpauseObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDpauseObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDpauseObjects1[k] = gdjs.LevelCode.GDpauseObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDpauseObjects1.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PauseBackground"), gdjs.LevelCode.GDPauseBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("PausedText"), gdjs.LevelCode.GDPausedTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.LevelCode.GDRestartObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitToMainMenu"), gdjs.LevelCode.GDexitToMainMenuObjects1);
{for(var i = 0, len = gdjs.LevelCode.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDPauseBackgroundObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.LevelCode.GDPausedTextObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDPausedTextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.LevelCode.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDexitToMainMenuObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.LevelCode.GDRestartObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDRestartObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.LevelCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Gravity"), gdjs.LevelCode.GDGravityObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDGravityObjects1.length;i<l;++i) {
    if ( gdjs.LevelCode.GDGravityObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDGravityObjects1[k] = gdjs.LevelCode.GDGravityObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDGravityObjects1.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.LevelCode.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.LevelCode.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDspawnBallObjects1[i].activateBehavior("Physics2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gravity"), gdjs.LevelCode.GDGravityObjects1);

gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.LevelCode.GDGravityObjects1.length;i<l;++i) {
    if ( !(gdjs.LevelCode.GDGravityObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.LevelCode.condition0IsTrue_0.val = true;
        gdjs.LevelCode.GDGravityObjects1[k] = gdjs.LevelCode.GDGravityObjects1[i];
        ++k;
    }
}
gdjs.LevelCode.GDGravityObjects1.length = k;}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.LevelCode.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.LevelCode.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.LevelCode.GDspawnBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{


gdjs.LevelCode.condition0IsTrue_0.val = false;
gdjs.LevelCode.condition1IsTrue_0.val = false;
{
gdjs.LevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.LevelCode.condition0IsTrue_0.val ) {
{
gdjs.LevelCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.LevelCode.condition1IsTrue_0.val) {
gdjs.LevelCode.GDspawnBallObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.LevelCode.mapOfGDgdjs_46LevelCode_46GDspawnBallObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}}

}


};

gdjs.LevelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LevelCode.GDleftWallObjects1.length = 0;
gdjs.LevelCode.GDleftWallObjects2.length = 0;
gdjs.LevelCode.GDrightWallObjects1.length = 0;
gdjs.LevelCode.GDrightWallObjects2.length = 0;
gdjs.LevelCode.GDbottomObjects1.length = 0;
gdjs.LevelCode.GDbottomObjects2.length = 0;
gdjs.LevelCode.GDBallObjects1.length = 0;
gdjs.LevelCode.GDBallObjects2.length = 0;
gdjs.LevelCode.GDspawnBallObjects1.length = 0;
gdjs.LevelCode.GDspawnBallObjects2.length = 0;
gdjs.LevelCode.GDGravityObjects1.length = 0;
gdjs.LevelCode.GDGravityObjects2.length = 0;
gdjs.LevelCode.GDmusicObjects1.length = 0;
gdjs.LevelCode.GDmusicObjects2.length = 0;
gdjs.LevelCode.GDgravityTextObjects1.length = 0;
gdjs.LevelCode.GDgravityTextObjects2.length = 0;
gdjs.LevelCode.GDfpsObjects1.length = 0;
gdjs.LevelCode.GDfpsObjects2.length = 0;
gdjs.LevelCode.GDpauseObjects1.length = 0;
gdjs.LevelCode.GDpauseObjects2.length = 0;
gdjs.LevelCode.GDPauseBackgroundObjects1.length = 0;
gdjs.LevelCode.GDPauseBackgroundObjects2.length = 0;
gdjs.LevelCode.GDPausedTextObjects1.length = 0;
gdjs.LevelCode.GDPausedTextObjects2.length = 0;
gdjs.LevelCode.GDexitToMainMenuObjects1.length = 0;
gdjs.LevelCode.GDexitToMainMenuObjects2.length = 0;
gdjs.LevelCode.GDRestartObjects1.length = 0;
gdjs.LevelCode.GDRestartObjects2.length = 0;
gdjs.LevelCode.GDGreenObjects1.length = 0;
gdjs.LevelCode.GDGreenObjects2.length = 0;

gdjs.LevelCode.eventsList3(runtimeScene);

return;

}

gdjs['LevelCode'] = gdjs.LevelCode;
