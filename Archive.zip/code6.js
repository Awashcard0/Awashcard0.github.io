gdjs.Level_325Code = {};
gdjs.Level_325Code.GDleftWallObjects1= [];
gdjs.Level_325Code.GDleftWallObjects2= [];
gdjs.Level_325Code.GDrightWallObjects1= [];
gdjs.Level_325Code.GDrightWallObjects2= [];
gdjs.Level_325Code.GDbottomObjects1= [];
gdjs.Level_325Code.GDbottomObjects2= [];
gdjs.Level_325Code.GDBallObjects1= [];
gdjs.Level_325Code.GDBallObjects2= [];
gdjs.Level_325Code.GDspawnBallObjects1= [];
gdjs.Level_325Code.GDspawnBallObjects2= [];
gdjs.Level_325Code.GDGravityObjects1= [];
gdjs.Level_325Code.GDGravityObjects2= [];
gdjs.Level_325Code.GDmusicObjects1= [];
gdjs.Level_325Code.GDmusicObjects2= [];
gdjs.Level_325Code.GDgravityTextObjects1= [];
gdjs.Level_325Code.GDgravityTextObjects2= [];
gdjs.Level_325Code.GDfpsObjects1= [];
gdjs.Level_325Code.GDfpsObjects2= [];
gdjs.Level_325Code.GDpauseObjects1= [];
gdjs.Level_325Code.GDpauseObjects2= [];
gdjs.Level_325Code.GDPauseBackgroundObjects1= [];
gdjs.Level_325Code.GDPauseBackgroundObjects2= [];
gdjs.Level_325Code.GDPausedTextObjects1= [];
gdjs.Level_325Code.GDPausedTextObjects2= [];
gdjs.Level_325Code.GDexitToMainMenuObjects1= [];
gdjs.Level_325Code.GDexitToMainMenuObjects2= [];
gdjs.Level_325Code.GDRestartObjects1= [];
gdjs.Level_325Code.GDRestartObjects2= [];
gdjs.Level_325Code.GDGreenObjects1= [];
gdjs.Level_325Code.GDGreenObjects2= [];
gdjs.Level_325Code.GDTargetObjects1= [];
gdjs.Level_325Code.GDTargetObjects2= [];
gdjs.Level_325Code.GDBlueFlatBarObjects1= [];
gdjs.Level_325Code.GDBlueFlatBarObjects2= [];

gdjs.Level_325Code.conditionTrue_0 = {val:false};
gdjs.Level_325Code.condition0IsTrue_0 = {val:false};
gdjs.Level_325Code.condition1IsTrue_0 = {val:false};
gdjs.Level_325Code.condition2IsTrue_0 = {val:false};


gdjs.Level_325Code.asyncCallback10151292 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_325Code.GDspawnBallObjects2);
{for(var i = 0, len = gdjs.Level_325Code.GDspawnBallObjects2.length ;i < len;++i) {
    gdjs.Level_325Code.GDspawnBallObjects2[i].activateBehavior("Physics2", true);
}
}{gdjs.evtsExt__DiscordRichPresence__UpdateRichPresence.func(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), "Hit somthing game", 0, 0, "", "", "", "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.window.setWindowTitle(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene) + " - Hit something");
}}
gdjs.Level_325Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_325Code.asyncCallback10151292(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.Level_325Code.GDBallObjects1});
gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDleftWallObjects1Objects = Hashtable.newFrom({"leftWall": gdjs.Level_325Code.GDleftWallObjects1});
gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.Level_325Code.GDBallObjects1});
gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDrightWallObjects1Objects = Hashtable.newFrom({"rightWall": gdjs.Level_325Code.GDrightWallObjects1});
gdjs.Level_325Code.asyncCallback10206140 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Level 6");
}}
gdjs.Level_325Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_325Code.asyncCallback10206140(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDpauseObjects1Objects = Hashtable.newFrom({"pause": gdjs.Level_325Code.GDpauseObjects1});
gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDPauseBackgroundObjects1Objects = Hashtable.newFrom({"PauseBackground": gdjs.Level_325Code.GDPauseBackgroundObjects1});
gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDPausedTextObjects1Objects = Hashtable.newFrom({"PausedText": gdjs.Level_325Code.GDPausedTextObjects1});
gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDexitToMainMenuObjects1Objects = Hashtable.newFrom({"exitToMainMenu": gdjs.Level_325Code.GDexitToMainMenuObjects1});
gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDRestartObjects1Objects = Hashtable.newFrom({"Restart": gdjs.Level_325Code.GDRestartObjects1});
gdjs.Level_325Code.asyncCallback10258076 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
gdjs.Level_325Code.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_325Code.asyncCallback10258076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_325Code.asyncCallback10263084 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
gdjs.Level_325Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_325Code.asyncCallback10263084(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDspawnBallObjects1Objects = Hashtable.newFrom({"spawnBall": gdjs.Level_325Code.GDspawnBallObjects1});
gdjs.Level_325Code.eventsList4 = function(runtimeScene) {

{


gdjs.Level_325Code.condition0IsTrue_0.val = false;
{
gdjs.Level_325Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_325Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_325Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_325Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("leftWall"), gdjs.Level_325Code.GDleftWallObjects1);

gdjs.Level_325Code.condition0IsTrue_0.val = false;
{
gdjs.Level_325Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDBallObjects1Objects, "Physics2", gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDleftWallObjects1Objects, false);
}if (gdjs.Level_325Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BlueFlatBar"), gdjs.Level_325Code.GDBlueFlatBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Target"), gdjs.Level_325Code.GDTargetObjects1);
{for(var i = 0, len = gdjs.Level_325Code.GDBlueFlatBarObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDBlueFlatBarObjects1[i].SetValue(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}{for(var i = 0, len = gdjs.Level_325Code.GDTargetObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDTargetObjects1[i].setString("Hit the right wall");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_325Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("rightWall"), gdjs.Level_325Code.GDrightWallObjects1);

gdjs.Level_325Code.condition0IsTrue_0.val = false;
gdjs.Level_325Code.condition1IsTrue_0.val = false;
{
gdjs.Level_325Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDBallObjects1Objects, "Physics2", gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDrightWallObjects1Objects, false);
}if ( gdjs.Level_325Code.condition0IsTrue_0.val ) {
{
gdjs.Level_325Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
}}
if (gdjs.Level_325Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BlueFlatBar"), gdjs.Level_325Code.GDBlueFlatBarObjects1);
{for(var i = 0, len = gdjs.Level_325Code.GDBlueFlatBarObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDBlueFlatBarObjects1[i].SetValue(2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Level_325Code.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.Level_325Code.condition0IsTrue_0.val = false;
{
gdjs.Level_325Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_325Code.condition0IsTrue_0.val) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}}

}


{



}


{


gdjs.Level_325Code.condition0IsTrue_0.val = false;
{
gdjs.Level_325Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_325Code.condition0IsTrue_0.val) {
gdjs.Level_325Code.GDpauseObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDpauseObjects1Objects, 1824, 18, "");
}{for(var i = 0, len = gdjs.Level_325Code.GDpauseObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDpauseObjects1[i].setScale(5);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.Level_325Code.GDpauseObjects1);

gdjs.Level_325Code.condition0IsTrue_0.val = false;
gdjs.Level_325Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_325Code.GDpauseObjects1.length;i<l;++i) {
    if ( gdjs.Level_325Code.GDpauseObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_325Code.condition0IsTrue_0.val = true;
        gdjs.Level_325Code.GDpauseObjects1[k] = gdjs.Level_325Code.GDpauseObjects1[i];
        ++k;
    }
}
gdjs.Level_325Code.GDpauseObjects1.length = k;}if ( gdjs.Level_325Code.condition0IsTrue_0.val ) {
{
gdjs.Level_325Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_325Code.condition1IsTrue_0.val) {
gdjs.Level_325Code.GDPauseBackgroundObjects1.length = 0;

gdjs.Level_325Code.GDPausedTextObjects1.length = 0;

gdjs.Level_325Code.GDRestartObjects1.length = 0;

gdjs.Level_325Code.GDexitToMainMenuObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDPauseBackgroundObjects1Objects, 548, 106, "");
}{for(var i = 0, len = gdjs.Level_325Code.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDPauseBackgroundObjects1[i].setHeight(805);
}
}{for(var i = 0, len = gdjs.Level_325Code.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDPauseBackgroundObjects1[i].setWidth(797);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDPausedTextObjects1Objects, 777, 187, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDexitToMainMenuObjects1Objects, 726, 678, "");
}{for(var i = 0, len = gdjs.Level_325Code.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDexitToMainMenuObjects1[i].setHeight(158);
}
}{for(var i = 0, len = gdjs.Level_325Code.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDexitToMainMenuObjects1[i].setWidth(418);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDRestartObjects1Objects, 748, 316, "");
}{for(var i = 0, len = gdjs.Level_325Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDRestartObjects1[i].setHeight(182);
}
}{for(var i = 0, len = gdjs.Level_325Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDRestartObjects1[i].setWidth(376);
}
}
{ //Subevents
gdjs.Level_325Code.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("exitToMainMenu"), gdjs.Level_325Code.GDexitToMainMenuObjects1);

gdjs.Level_325Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_325Code.GDexitToMainMenuObjects1.length;i<l;++i) {
    if ( gdjs.Level_325Code.GDexitToMainMenuObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_325Code.condition0IsTrue_0.val = true;
        gdjs.Level_325Code.GDexitToMainMenuObjects1[k] = gdjs.Level_325Code.GDexitToMainMenuObjects1[i];
        ++k;
    }
}
gdjs.Level_325Code.GDexitToMainMenuObjects1.length = k;}if (gdjs.Level_325Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Start menu");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Level_325Code.GDRestartObjects1);

gdjs.Level_325Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_325Code.GDRestartObjects1.length;i<l;++i) {
    if ( gdjs.Level_325Code.GDRestartObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_325Code.condition0IsTrue_0.val = true;
        gdjs.Level_325Code.GDRestartObjects1[k] = gdjs.Level_325Code.GDRestartObjects1[i];
        ++k;
    }
}
gdjs.Level_325Code.GDRestartObjects1.length = k;}if (gdjs.Level_325Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene));
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{


gdjs.Level_325Code.condition0IsTrue_0.val = false;
{
gdjs.Level_325Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if (gdjs.Level_325Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_325Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_325Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_325Code.GDBallObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDBallObjects1[i].activateBehavior("Physics2", false);
}
}{for(var i = 0, len = gdjs.Level_325Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDspawnBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{


gdjs.Level_325Code.condition0IsTrue_0.val = false;
{
gdjs.Level_325Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if (gdjs.Level_325Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_325Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_325Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_325Code.GDBallObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDBallObjects1[i].activateBehavior("Physics2", true);
}
}{for(var i = 0, len = gdjs.Level_325Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDspawnBallObjects1[i].activateBehavior("Physics2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.Level_325Code.GDpauseObjects1);

gdjs.Level_325Code.condition0IsTrue_0.val = false;
gdjs.Level_325Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_325Code.GDpauseObjects1.length;i<l;++i) {
    if ( gdjs.Level_325Code.GDpauseObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_325Code.condition0IsTrue_0.val = true;
        gdjs.Level_325Code.GDpauseObjects1[k] = gdjs.Level_325Code.GDpauseObjects1[i];
        ++k;
    }
}
gdjs.Level_325Code.GDpauseObjects1.length = k;}if ( gdjs.Level_325Code.condition0IsTrue_0.val ) {
{
gdjs.Level_325Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
if (gdjs.Level_325Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PauseBackground"), gdjs.Level_325Code.GDPauseBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("PausedText"), gdjs.Level_325Code.GDPausedTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Level_325Code.GDRestartObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitToMainMenu"), gdjs.Level_325Code.GDexitToMainMenuObjects1);
{for(var i = 0, len = gdjs.Level_325Code.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDPauseBackgroundObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_325Code.GDPausedTextObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDPausedTextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_325Code.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDexitToMainMenuObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_325Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDRestartObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level_325Code.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Gravity"), gdjs.Level_325Code.GDGravityObjects1);

gdjs.Level_325Code.condition0IsTrue_0.val = false;
gdjs.Level_325Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_325Code.GDGravityObjects1.length;i<l;++i) {
    if ( gdjs.Level_325Code.GDGravityObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_325Code.condition0IsTrue_0.val = true;
        gdjs.Level_325Code.GDGravityObjects1[k] = gdjs.Level_325Code.GDGravityObjects1[i];
        ++k;
    }
}
gdjs.Level_325Code.GDGravityObjects1.length = k;}if ( gdjs.Level_325Code.condition0IsTrue_0.val ) {
{
gdjs.Level_325Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_325Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_325Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_325Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDspawnBallObjects1[i].activateBehavior("Physics2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gravity"), gdjs.Level_325Code.GDGravityObjects1);

gdjs.Level_325Code.condition0IsTrue_0.val = false;
gdjs.Level_325Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_325Code.GDGravityObjects1.length;i<l;++i) {
    if ( !(gdjs.Level_325Code.GDGravityObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.Level_325Code.condition0IsTrue_0.val = true;
        gdjs.Level_325Code.GDGravityObjects1[k] = gdjs.Level_325Code.GDGravityObjects1[i];
        ++k;
    }
}
gdjs.Level_325Code.GDGravityObjects1.length = k;}if ( gdjs.Level_325Code.condition0IsTrue_0.val ) {
{
gdjs.Level_325Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_325Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_325Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_325Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_325Code.GDspawnBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{


gdjs.Level_325Code.condition0IsTrue_0.val = false;
gdjs.Level_325Code.condition1IsTrue_0.val = false;
{
gdjs.Level_325Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_325Code.condition0IsTrue_0.val ) {
{
gdjs.Level_325Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_325Code.condition1IsTrue_0.val) {
gdjs.Level_325Code.GDspawnBallObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_325Code.mapOfGDgdjs_46Level_95325Code_46GDspawnBallObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}}

}


};

gdjs.Level_325Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_325Code.GDleftWallObjects1.length = 0;
gdjs.Level_325Code.GDleftWallObjects2.length = 0;
gdjs.Level_325Code.GDrightWallObjects1.length = 0;
gdjs.Level_325Code.GDrightWallObjects2.length = 0;
gdjs.Level_325Code.GDbottomObjects1.length = 0;
gdjs.Level_325Code.GDbottomObjects2.length = 0;
gdjs.Level_325Code.GDBallObjects1.length = 0;
gdjs.Level_325Code.GDBallObjects2.length = 0;
gdjs.Level_325Code.GDspawnBallObjects1.length = 0;
gdjs.Level_325Code.GDspawnBallObjects2.length = 0;
gdjs.Level_325Code.GDGravityObjects1.length = 0;
gdjs.Level_325Code.GDGravityObjects2.length = 0;
gdjs.Level_325Code.GDmusicObjects1.length = 0;
gdjs.Level_325Code.GDmusicObjects2.length = 0;
gdjs.Level_325Code.GDgravityTextObjects1.length = 0;
gdjs.Level_325Code.GDgravityTextObjects2.length = 0;
gdjs.Level_325Code.GDfpsObjects1.length = 0;
gdjs.Level_325Code.GDfpsObjects2.length = 0;
gdjs.Level_325Code.GDpauseObjects1.length = 0;
gdjs.Level_325Code.GDpauseObjects2.length = 0;
gdjs.Level_325Code.GDPauseBackgroundObjects1.length = 0;
gdjs.Level_325Code.GDPauseBackgroundObjects2.length = 0;
gdjs.Level_325Code.GDPausedTextObjects1.length = 0;
gdjs.Level_325Code.GDPausedTextObjects2.length = 0;
gdjs.Level_325Code.GDexitToMainMenuObjects1.length = 0;
gdjs.Level_325Code.GDexitToMainMenuObjects2.length = 0;
gdjs.Level_325Code.GDRestartObjects1.length = 0;
gdjs.Level_325Code.GDRestartObjects2.length = 0;
gdjs.Level_325Code.GDGreenObjects1.length = 0;
gdjs.Level_325Code.GDGreenObjects2.length = 0;
gdjs.Level_325Code.GDTargetObjects1.length = 0;
gdjs.Level_325Code.GDTargetObjects2.length = 0;
gdjs.Level_325Code.GDBlueFlatBarObjects1.length = 0;
gdjs.Level_325Code.GDBlueFlatBarObjects2.length = 0;

gdjs.Level_325Code.eventsList4(runtimeScene);

return;

}

gdjs['Level_325Code'] = gdjs.Level_325Code;
