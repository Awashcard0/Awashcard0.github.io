gdjs.Level_322Code = {};
gdjs.Level_322Code.GDleftWallObjects1= [];
gdjs.Level_322Code.GDleftWallObjects2= [];
gdjs.Level_322Code.GDrightWallObjects1= [];
gdjs.Level_322Code.GDrightWallObjects2= [];
gdjs.Level_322Code.GDbottomObjects1= [];
gdjs.Level_322Code.GDbottomObjects2= [];
gdjs.Level_322Code.GDBallObjects1= [];
gdjs.Level_322Code.GDBallObjects2= [];
gdjs.Level_322Code.GDspawnBallObjects1= [];
gdjs.Level_322Code.GDspawnBallObjects2= [];
gdjs.Level_322Code.GDGravityObjects1= [];
gdjs.Level_322Code.GDGravityObjects2= [];
gdjs.Level_322Code.GDmusicObjects1= [];
gdjs.Level_322Code.GDmusicObjects2= [];
gdjs.Level_322Code.GDgravityTextObjects1= [];
gdjs.Level_322Code.GDgravityTextObjects2= [];
gdjs.Level_322Code.GDfpsObjects1= [];
gdjs.Level_322Code.GDfpsObjects2= [];
gdjs.Level_322Code.GDpauseObjects1= [];
gdjs.Level_322Code.GDpauseObjects2= [];
gdjs.Level_322Code.GDPauseBackgroundObjects1= [];
gdjs.Level_322Code.GDPauseBackgroundObjects2= [];
gdjs.Level_322Code.GDPausedTextObjects1= [];
gdjs.Level_322Code.GDPausedTextObjects2= [];
gdjs.Level_322Code.GDexitToMainMenuObjects1= [];
gdjs.Level_322Code.GDexitToMainMenuObjects2= [];
gdjs.Level_322Code.GDRestartObjects1= [];
gdjs.Level_322Code.GDRestartObjects2= [];
gdjs.Level_322Code.GDGreenObjects1= [];
gdjs.Level_322Code.GDGreenObjects2= [];
gdjs.Level_322Code.GDNewTextObjects1= [];
gdjs.Level_322Code.GDNewTextObjects2= [];

gdjs.Level_322Code.conditionTrue_0 = {val:false};
gdjs.Level_322Code.condition0IsTrue_0 = {val:false};
gdjs.Level_322Code.condition1IsTrue_0 = {val:false};
gdjs.Level_322Code.condition2IsTrue_0 = {val:false};


gdjs.Level_322Code.asyncCallback10199508 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_322Code.GDspawnBallObjects2);
{for(var i = 0, len = gdjs.Level_322Code.GDspawnBallObjects2.length ;i < len;++i) {
    gdjs.Level_322Code.GDspawnBallObjects2[i].activateBehavior("Physics2", true);
}
}{gdjs.evtsExt__DiscordRichPresence__UpdateRichPresence.func(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), "Hit somthing game", 0, 0, "", "", "", "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.window.setWindowTitle(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene) + " - Hit something");
}}
gdjs.Level_322Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_322Code.asyncCallback10199508(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.Level_322Code.GDBallObjects1});
gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDrightWallObjects1Objects = Hashtable.newFrom({"rightWall": gdjs.Level_322Code.GDrightWallObjects1});
gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDpauseObjects1Objects = Hashtable.newFrom({"pause": gdjs.Level_322Code.GDpauseObjects1});
gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDPauseBackgroundObjects1Objects = Hashtable.newFrom({"PauseBackground": gdjs.Level_322Code.GDPauseBackgroundObjects1});
gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDPausedTextObjects1Objects = Hashtable.newFrom({"PausedText": gdjs.Level_322Code.GDPausedTextObjects1});
gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDexitToMainMenuObjects1Objects = Hashtable.newFrom({"exitToMainMenu": gdjs.Level_322Code.GDexitToMainMenuObjects1});
gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDRestartObjects1Objects = Hashtable.newFrom({"Restart": gdjs.Level_322Code.GDRestartObjects1});
gdjs.Level_322Code.asyncCallback10258076 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
gdjs.Level_322Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_322Code.asyncCallback10258076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_322Code.asyncCallback10263084 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
gdjs.Level_322Code.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_322Code.asyncCallback10263084(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDspawnBallObjects1Objects = Hashtable.newFrom({"spawnBall": gdjs.Level_322Code.GDspawnBallObjects1});
gdjs.Level_322Code.eventsList3 = function(runtimeScene) {

{


gdjs.Level_322Code.condition0IsTrue_0.val = false;
{
gdjs.Level_322Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_322Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_322Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_322Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("rightWall"), gdjs.Level_322Code.GDrightWallObjects1);

gdjs.Level_322Code.condition0IsTrue_0.val = false;
{
gdjs.Level_322Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDBallObjects1Objects, "Physics2", gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDrightWallObjects1Objects, false);
}if (gdjs.Level_322Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Level 3");
}}

}


{



}


{


gdjs.Level_322Code.condition0IsTrue_0.val = false;
{
gdjs.Level_322Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_322Code.condition0IsTrue_0.val) {
gdjs.Level_322Code.GDpauseObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDpauseObjects1Objects, 1824, 18, "");
}{for(var i = 0, len = gdjs.Level_322Code.GDpauseObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDpauseObjects1[i].setScale(5);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.Level_322Code.GDpauseObjects1);

gdjs.Level_322Code.condition0IsTrue_0.val = false;
gdjs.Level_322Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_322Code.GDpauseObjects1.length;i<l;++i) {
    if ( gdjs.Level_322Code.GDpauseObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_322Code.condition0IsTrue_0.val = true;
        gdjs.Level_322Code.GDpauseObjects1[k] = gdjs.Level_322Code.GDpauseObjects1[i];
        ++k;
    }
}
gdjs.Level_322Code.GDpauseObjects1.length = k;}if ( gdjs.Level_322Code.condition0IsTrue_0.val ) {
{
gdjs.Level_322Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_322Code.condition1IsTrue_0.val) {
gdjs.Level_322Code.GDPauseBackgroundObjects1.length = 0;

gdjs.Level_322Code.GDPausedTextObjects1.length = 0;

gdjs.Level_322Code.GDRestartObjects1.length = 0;

gdjs.Level_322Code.GDexitToMainMenuObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDPauseBackgroundObjects1Objects, 548, 106, "");
}{for(var i = 0, len = gdjs.Level_322Code.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDPauseBackgroundObjects1[i].setHeight(805);
}
}{for(var i = 0, len = gdjs.Level_322Code.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDPauseBackgroundObjects1[i].setWidth(797);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDPausedTextObjects1Objects, 777, 187, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDexitToMainMenuObjects1Objects, 726, 678, "");
}{for(var i = 0, len = gdjs.Level_322Code.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDexitToMainMenuObjects1[i].setHeight(158);
}
}{for(var i = 0, len = gdjs.Level_322Code.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDexitToMainMenuObjects1[i].setWidth(418);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDRestartObjects1Objects, 748, 316, "");
}{for(var i = 0, len = gdjs.Level_322Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDRestartObjects1[i].setHeight(182);
}
}{for(var i = 0, len = gdjs.Level_322Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDRestartObjects1[i].setWidth(376);
}
}
{ //Subevents
gdjs.Level_322Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("exitToMainMenu"), gdjs.Level_322Code.GDexitToMainMenuObjects1);

gdjs.Level_322Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_322Code.GDexitToMainMenuObjects1.length;i<l;++i) {
    if ( gdjs.Level_322Code.GDexitToMainMenuObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_322Code.condition0IsTrue_0.val = true;
        gdjs.Level_322Code.GDexitToMainMenuObjects1[k] = gdjs.Level_322Code.GDexitToMainMenuObjects1[i];
        ++k;
    }
}
gdjs.Level_322Code.GDexitToMainMenuObjects1.length = k;}if (gdjs.Level_322Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Start menu");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Level_322Code.GDRestartObjects1);

gdjs.Level_322Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_322Code.GDRestartObjects1.length;i<l;++i) {
    if ( gdjs.Level_322Code.GDRestartObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_322Code.condition0IsTrue_0.val = true;
        gdjs.Level_322Code.GDRestartObjects1[k] = gdjs.Level_322Code.GDRestartObjects1[i];
        ++k;
    }
}
gdjs.Level_322Code.GDRestartObjects1.length = k;}if (gdjs.Level_322Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene));
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{


gdjs.Level_322Code.condition0IsTrue_0.val = false;
{
gdjs.Level_322Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if (gdjs.Level_322Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_322Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_322Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_322Code.GDBallObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDBallObjects1[i].activateBehavior("Physics2", false);
}
}{for(var i = 0, len = gdjs.Level_322Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDspawnBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{


gdjs.Level_322Code.condition0IsTrue_0.val = false;
{
gdjs.Level_322Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if (gdjs.Level_322Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_322Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_322Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_322Code.GDBallObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDBallObjects1[i].activateBehavior("Physics2", true);
}
}{for(var i = 0, len = gdjs.Level_322Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDspawnBallObjects1[i].activateBehavior("Physics2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.Level_322Code.GDpauseObjects1);

gdjs.Level_322Code.condition0IsTrue_0.val = false;
gdjs.Level_322Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_322Code.GDpauseObjects1.length;i<l;++i) {
    if ( gdjs.Level_322Code.GDpauseObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_322Code.condition0IsTrue_0.val = true;
        gdjs.Level_322Code.GDpauseObjects1[k] = gdjs.Level_322Code.GDpauseObjects1[i];
        ++k;
    }
}
gdjs.Level_322Code.GDpauseObjects1.length = k;}if ( gdjs.Level_322Code.condition0IsTrue_0.val ) {
{
gdjs.Level_322Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
if (gdjs.Level_322Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PauseBackground"), gdjs.Level_322Code.GDPauseBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("PausedText"), gdjs.Level_322Code.GDPausedTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Level_322Code.GDRestartObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitToMainMenu"), gdjs.Level_322Code.GDexitToMainMenuObjects1);
{for(var i = 0, len = gdjs.Level_322Code.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDPauseBackgroundObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_322Code.GDPausedTextObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDPausedTextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_322Code.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDexitToMainMenuObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_322Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDRestartObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level_322Code.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Gravity"), gdjs.Level_322Code.GDGravityObjects1);

gdjs.Level_322Code.condition0IsTrue_0.val = false;
gdjs.Level_322Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_322Code.GDGravityObjects1.length;i<l;++i) {
    if ( gdjs.Level_322Code.GDGravityObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_322Code.condition0IsTrue_0.val = true;
        gdjs.Level_322Code.GDGravityObjects1[k] = gdjs.Level_322Code.GDGravityObjects1[i];
        ++k;
    }
}
gdjs.Level_322Code.GDGravityObjects1.length = k;}if ( gdjs.Level_322Code.condition0IsTrue_0.val ) {
{
gdjs.Level_322Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_322Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_322Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_322Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDspawnBallObjects1[i].activateBehavior("Physics2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gravity"), gdjs.Level_322Code.GDGravityObjects1);

gdjs.Level_322Code.condition0IsTrue_0.val = false;
gdjs.Level_322Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_322Code.GDGravityObjects1.length;i<l;++i) {
    if ( !(gdjs.Level_322Code.GDGravityObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.Level_322Code.condition0IsTrue_0.val = true;
        gdjs.Level_322Code.GDGravityObjects1[k] = gdjs.Level_322Code.GDGravityObjects1[i];
        ++k;
    }
}
gdjs.Level_322Code.GDGravityObjects1.length = k;}if ( gdjs.Level_322Code.condition0IsTrue_0.val ) {
{
gdjs.Level_322Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_322Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_322Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_322Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_322Code.GDspawnBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{


gdjs.Level_322Code.condition0IsTrue_0.val = false;
gdjs.Level_322Code.condition1IsTrue_0.val = false;
{
gdjs.Level_322Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_322Code.condition0IsTrue_0.val ) {
{
gdjs.Level_322Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_322Code.condition1IsTrue_0.val) {
gdjs.Level_322Code.GDspawnBallObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_322Code.mapOfGDgdjs_46Level_95322Code_46GDspawnBallObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}}

}


};

gdjs.Level_322Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_322Code.GDleftWallObjects1.length = 0;
gdjs.Level_322Code.GDleftWallObjects2.length = 0;
gdjs.Level_322Code.GDrightWallObjects1.length = 0;
gdjs.Level_322Code.GDrightWallObjects2.length = 0;
gdjs.Level_322Code.GDbottomObjects1.length = 0;
gdjs.Level_322Code.GDbottomObjects2.length = 0;
gdjs.Level_322Code.GDBallObjects1.length = 0;
gdjs.Level_322Code.GDBallObjects2.length = 0;
gdjs.Level_322Code.GDspawnBallObjects1.length = 0;
gdjs.Level_322Code.GDspawnBallObjects2.length = 0;
gdjs.Level_322Code.GDGravityObjects1.length = 0;
gdjs.Level_322Code.GDGravityObjects2.length = 0;
gdjs.Level_322Code.GDmusicObjects1.length = 0;
gdjs.Level_322Code.GDmusicObjects2.length = 0;
gdjs.Level_322Code.GDgravityTextObjects1.length = 0;
gdjs.Level_322Code.GDgravityTextObjects2.length = 0;
gdjs.Level_322Code.GDfpsObjects1.length = 0;
gdjs.Level_322Code.GDfpsObjects2.length = 0;
gdjs.Level_322Code.GDpauseObjects1.length = 0;
gdjs.Level_322Code.GDpauseObjects2.length = 0;
gdjs.Level_322Code.GDPauseBackgroundObjects1.length = 0;
gdjs.Level_322Code.GDPauseBackgroundObjects2.length = 0;
gdjs.Level_322Code.GDPausedTextObjects1.length = 0;
gdjs.Level_322Code.GDPausedTextObjects2.length = 0;
gdjs.Level_322Code.GDexitToMainMenuObjects1.length = 0;
gdjs.Level_322Code.GDexitToMainMenuObjects2.length = 0;
gdjs.Level_322Code.GDRestartObjects1.length = 0;
gdjs.Level_322Code.GDRestartObjects2.length = 0;
gdjs.Level_322Code.GDGreenObjects1.length = 0;
gdjs.Level_322Code.GDGreenObjects2.length = 0;
gdjs.Level_322Code.GDNewTextObjects1.length = 0;
gdjs.Level_322Code.GDNewTextObjects2.length = 0;

gdjs.Level_322Code.eventsList3(runtimeScene);

return;

}

gdjs['Level_322Code'] = gdjs.Level_322Code;
