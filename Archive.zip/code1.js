gdjs.Start_32menuCode = {};
gdjs.Start_32menuCode.GDleftWallObjects1= [];
gdjs.Start_32menuCode.GDleftWallObjects2= [];
gdjs.Start_32menuCode.GDrightWallObjects1= [];
gdjs.Start_32menuCode.GDrightWallObjects2= [];
gdjs.Start_32menuCode.GDbottomObjects1= [];
gdjs.Start_32menuCode.GDbottomObjects2= [];
gdjs.Start_32menuCode.GDBallObjects1= [];
gdjs.Start_32menuCode.GDBallObjects2= [];
gdjs.Start_32menuCode.GDspawnBallObjects1= [];
gdjs.Start_32menuCode.GDspawnBallObjects2= [];
gdjs.Start_32menuCode.GDGravityObjects1= [];
gdjs.Start_32menuCode.GDGravityObjects2= [];
gdjs.Start_32menuCode.GDmusicObjects1= [];
gdjs.Start_32menuCode.GDmusicObjects2= [];
gdjs.Start_32menuCode.GDgravityTextObjects1= [];
gdjs.Start_32menuCode.GDgravityTextObjects2= [];
gdjs.Start_32menuCode.GDfpsObjects1= [];
gdjs.Start_32menuCode.GDfpsObjects2= [];
gdjs.Start_32menuCode.GDpauseObjects1= [];
gdjs.Start_32menuCode.GDpauseObjects2= [];
gdjs.Start_32menuCode.GDPauseBackgroundObjects1= [];
gdjs.Start_32menuCode.GDPauseBackgroundObjects2= [];
gdjs.Start_32menuCode.GDPausedTextObjects1= [];
gdjs.Start_32menuCode.GDPausedTextObjects2= [];
gdjs.Start_32menuCode.GDexitToMainMenuObjects1= [];
gdjs.Start_32menuCode.GDexitToMainMenuObjects2= [];
gdjs.Start_32menuCode.GDRestartObjects1= [];
gdjs.Start_32menuCode.GDRestartObjects2= [];
gdjs.Start_32menuCode.GDGreenObjects1= [];
gdjs.Start_32menuCode.GDGreenObjects2= [];
gdjs.Start_32menuCode.GDBackgroundBlueLandObjects1= [];
gdjs.Start_32menuCode.GDBackgroundBlueLandObjects2= [];
gdjs.Start_32menuCode.GDGreyButtonObjects1= [];
gdjs.Start_32menuCode.GDGreyButtonObjects2= [];
gdjs.Start_32menuCode.GDGameObjects1= [];
gdjs.Start_32menuCode.GDGameObjects2= [];
gdjs.Start_32menuCode.GDYellowButtonObjects1= [];
gdjs.Start_32menuCode.GDYellowButtonObjects2= [];
gdjs.Start_32menuCode.GDExitObjects1= [];
gdjs.Start_32menuCode.GDExitObjects2= [];
gdjs.Start_32menuCode.GDsiteObjects1= [];
gdjs.Start_32menuCode.GDsiteObjects2= [];
gdjs.Start_32menuCode.GDNewVideoObjects1= [];
gdjs.Start_32menuCode.GDNewVideoObjects2= [];
gdjs.Start_32menuCode.GDUpdateObjects1= [];
gdjs.Start_32menuCode.GDUpdateObjects2= [];
gdjs.Start_32menuCode.GDupdatetextObjects1= [];
gdjs.Start_32menuCode.GDupdatetextObjects2= [];
gdjs.Start_32menuCode.GDmusictextObjects1= [];
gdjs.Start_32menuCode.GDmusictextObjects2= [];

gdjs.Start_32menuCode.conditionTrue_0 = {val:false};
gdjs.Start_32menuCode.condition0IsTrue_0 = {val:false};
gdjs.Start_32menuCode.condition1IsTrue_0 = {val:false};


gdjs.Start_32menuCode.asyncCallback10153596 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("updatetext"), gdjs.Start_32menuCode.GDupdatetextObjects2);
{for(var i = 0, len = gdjs.Start_32menuCode.GDupdatetextObjects2.length ;i < len;++i) {
    gdjs.Start_32menuCode.GDupdatetextObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)));
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}}
gdjs.Start_32menuCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.network.sendAwaitableAsyncRequest("https://awashcard0.pages.dev/games/hit-the-thing/Updatelog.txt", "", "GET", "", runtimeScene.getScene().getVariables().getFromIndex(0), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.Start_32menuCode.asyncCallback10153596(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32menuCode.asyncCallback10156580 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("NewVideo"), gdjs.Start_32menuCode.GDNewVideoObjects2);

{for(var i = 0, len = gdjs.Start_32menuCode.GDNewVideoObjects2.length ;i < len;++i) {
    gdjs.Start_32menuCode.GDNewVideoObjects2[i].hide();
}
}}
gdjs.Start_32menuCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Start_32menuCode.GDNewVideoObjects1) asyncObjectsList.addObject("NewVideo", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(38), (runtimeScene) => (gdjs.Start_32menuCode.asyncCallback10156580(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Start_32menuCode.eventsList2 = function(runtimeScene) {

{


gdjs.Start_32menuCode.condition0IsTrue_0.val = false;
{
gdjs.Start_32menuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Start_32menuCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewVideo"), gdjs.Start_32menuCode.GDNewVideoObjects1);
{gdjs.evtsExt__DiscordRichPresence__ConnectToDiscord.func(runtimeScene, "1085211667140456499", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__DiscordRichPresence__UpdateRichPresence.func(runtimeScene, "Hit somthing", "In the start menu", 0, 0, "", "", "", "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.window.setWindowTitle(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene) + " - Hit something");
}{for(var i = 0, len = gdjs.Start_32menuCode.GDNewVideoObjects1.length ;i < len;++i) {
    gdjs.Start_32menuCode.GDNewVideoObjects1[i].hide();
}
}
{ //Subevents
gdjs.Start_32menuCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("YellowButton"), gdjs.Start_32menuCode.GDYellowButtonObjects1);

gdjs.Start_32menuCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32menuCode.GDYellowButtonObjects1.length;i<l;++i) {
    if ( gdjs.Start_32menuCode.GDYellowButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Start_32menuCode.condition0IsTrue_0.val = true;
        gdjs.Start_32menuCode.GDYellowButtonObjects1[k] = gdjs.Start_32menuCode.GDYellowButtonObjects1[i];
        ++k;
    }
}
gdjs.Start_32menuCode.GDYellowButtonObjects1.length = k;}if (gdjs.Start_32menuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Level 1");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Start_32menuCode.GDExitObjects1);

gdjs.Start_32menuCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32menuCode.GDExitObjects1.length;i<l;++i) {
    if ( gdjs.Start_32menuCode.GDExitObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Start_32menuCode.condition0IsTrue_0.val = true;
        gdjs.Start_32menuCode.GDExitObjects1[k] = gdjs.Start_32menuCode.GDExitObjects1[i];
        ++k;
    }
}
gdjs.Start_32menuCode.GDExitObjects1.length = k;}if (gdjs.Start_32menuCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewVideo"), gdjs.Start_32menuCode.GDNewVideoObjects1);
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}{for(var i = 0, len = gdjs.Start_32menuCode.GDNewVideoObjects1.length ;i < len;++i) {
    gdjs.Start_32menuCode.GDNewVideoObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Start_32menuCode.GDNewVideoObjects1.length ;i < len;++i) {
    gdjs.Start_32menuCode.GDNewVideoObjects1[i].play();
}
}
{ //Subevents
gdjs.Start_32menuCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("site"), gdjs.Start_32menuCode.GDsiteObjects1);

gdjs.Start_32menuCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32menuCode.GDsiteObjects1.length;i<l;++i) {
    if ( gdjs.Start_32menuCode.GDsiteObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Start_32menuCode.condition0IsTrue_0.val = true;
        gdjs.Start_32menuCode.GDsiteObjects1[k] = gdjs.Start_32menuCode.GDsiteObjects1[i];
        ++k;
    }
}
gdjs.Start_32menuCode.GDsiteObjects1.length = k;}if (gdjs.Start_32menuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.window.openURL("https://awashcard0.pages.dev/games", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music"), gdjs.Start_32menuCode.GDmusicObjects1);

gdjs.Start_32menuCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32menuCode.GDmusicObjects1.length;i<l;++i) {
    if ( gdjs.Start_32menuCode.GDmusicObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Start_32menuCode.condition0IsTrue_0.val = true;
        gdjs.Start_32menuCode.GDmusicObjects1[k] = gdjs.Start_32menuCode.GDmusicObjects1[i];
        ++k;
    }
}
gdjs.Start_32menuCode.GDmusicObjects1.length = k;}if (gdjs.Start_32menuCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(100);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music"), gdjs.Start_32menuCode.GDmusicObjects1);

gdjs.Start_32menuCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Start_32menuCode.GDmusicObjects1.length;i<l;++i) {
    if ( !(gdjs.Start_32menuCode.GDmusicObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.Start_32menuCode.condition0IsTrue_0.val = true;
        gdjs.Start_32menuCode.GDmusicObjects1[k] = gdjs.Start_32menuCode.GDmusicObjects1[i];
        ++k;
    }
}
gdjs.Start_32menuCode.GDmusicObjects1.length = k;}if (gdjs.Start_32menuCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}}

}


};

gdjs.Start_32menuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Start_32menuCode.GDleftWallObjects1.length = 0;
gdjs.Start_32menuCode.GDleftWallObjects2.length = 0;
gdjs.Start_32menuCode.GDrightWallObjects1.length = 0;
gdjs.Start_32menuCode.GDrightWallObjects2.length = 0;
gdjs.Start_32menuCode.GDbottomObjects1.length = 0;
gdjs.Start_32menuCode.GDbottomObjects2.length = 0;
gdjs.Start_32menuCode.GDBallObjects1.length = 0;
gdjs.Start_32menuCode.GDBallObjects2.length = 0;
gdjs.Start_32menuCode.GDspawnBallObjects1.length = 0;
gdjs.Start_32menuCode.GDspawnBallObjects2.length = 0;
gdjs.Start_32menuCode.GDGravityObjects1.length = 0;
gdjs.Start_32menuCode.GDGravityObjects2.length = 0;
gdjs.Start_32menuCode.GDmusicObjects1.length = 0;
gdjs.Start_32menuCode.GDmusicObjects2.length = 0;
gdjs.Start_32menuCode.GDgravityTextObjects1.length = 0;
gdjs.Start_32menuCode.GDgravityTextObjects2.length = 0;
gdjs.Start_32menuCode.GDfpsObjects1.length = 0;
gdjs.Start_32menuCode.GDfpsObjects2.length = 0;
gdjs.Start_32menuCode.GDpauseObjects1.length = 0;
gdjs.Start_32menuCode.GDpauseObjects2.length = 0;
gdjs.Start_32menuCode.GDPauseBackgroundObjects1.length = 0;
gdjs.Start_32menuCode.GDPauseBackgroundObjects2.length = 0;
gdjs.Start_32menuCode.GDPausedTextObjects1.length = 0;
gdjs.Start_32menuCode.GDPausedTextObjects2.length = 0;
gdjs.Start_32menuCode.GDexitToMainMenuObjects1.length = 0;
gdjs.Start_32menuCode.GDexitToMainMenuObjects2.length = 0;
gdjs.Start_32menuCode.GDRestartObjects1.length = 0;
gdjs.Start_32menuCode.GDRestartObjects2.length = 0;
gdjs.Start_32menuCode.GDGreenObjects1.length = 0;
gdjs.Start_32menuCode.GDGreenObjects2.length = 0;
gdjs.Start_32menuCode.GDBackgroundBlueLandObjects1.length = 0;
gdjs.Start_32menuCode.GDBackgroundBlueLandObjects2.length = 0;
gdjs.Start_32menuCode.GDGreyButtonObjects1.length = 0;
gdjs.Start_32menuCode.GDGreyButtonObjects2.length = 0;
gdjs.Start_32menuCode.GDGameObjects1.length = 0;
gdjs.Start_32menuCode.GDGameObjects2.length = 0;
gdjs.Start_32menuCode.GDYellowButtonObjects1.length = 0;
gdjs.Start_32menuCode.GDYellowButtonObjects2.length = 0;
gdjs.Start_32menuCode.GDExitObjects1.length = 0;
gdjs.Start_32menuCode.GDExitObjects2.length = 0;
gdjs.Start_32menuCode.GDsiteObjects1.length = 0;
gdjs.Start_32menuCode.GDsiteObjects2.length = 0;
gdjs.Start_32menuCode.GDNewVideoObjects1.length = 0;
gdjs.Start_32menuCode.GDNewVideoObjects2.length = 0;
gdjs.Start_32menuCode.GDUpdateObjects1.length = 0;
gdjs.Start_32menuCode.GDUpdateObjects2.length = 0;
gdjs.Start_32menuCode.GDupdatetextObjects1.length = 0;
gdjs.Start_32menuCode.GDupdatetextObjects2.length = 0;
gdjs.Start_32menuCode.GDmusictextObjects1.length = 0;
gdjs.Start_32menuCode.GDmusictextObjects2.length = 0;

gdjs.Start_32menuCode.eventsList2(runtimeScene);

return;

}

gdjs['Start_32menuCode'] = gdjs.Start_32menuCode;
