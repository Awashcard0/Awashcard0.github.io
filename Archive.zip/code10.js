gdjs.Level_329Code = {};
gdjs.Level_329Code.GDleftWallObjects1= [];
gdjs.Level_329Code.GDleftWallObjects2= [];
gdjs.Level_329Code.GDrightWallObjects1= [];
gdjs.Level_329Code.GDrightWallObjects2= [];
gdjs.Level_329Code.GDbottomObjects1= [];
gdjs.Level_329Code.GDbottomObjects2= [];
gdjs.Level_329Code.GDBallObjects1= [];
gdjs.Level_329Code.GDBallObjects2= [];
gdjs.Level_329Code.GDspawnBallObjects1= [];
gdjs.Level_329Code.GDspawnBallObjects2= [];
gdjs.Level_329Code.GDGravityObjects1= [];
gdjs.Level_329Code.GDGravityObjects2= [];
gdjs.Level_329Code.GDmusicObjects1= [];
gdjs.Level_329Code.GDmusicObjects2= [];
gdjs.Level_329Code.GDgravityTextObjects1= [];
gdjs.Level_329Code.GDgravityTextObjects2= [];
gdjs.Level_329Code.GDfpsObjects1= [];
gdjs.Level_329Code.GDfpsObjects2= [];
gdjs.Level_329Code.GDpauseObjects1= [];
gdjs.Level_329Code.GDpauseObjects2= [];
gdjs.Level_329Code.GDPauseBackgroundObjects1= [];
gdjs.Level_329Code.GDPauseBackgroundObjects2= [];
gdjs.Level_329Code.GDPausedTextObjects1= [];
gdjs.Level_329Code.GDPausedTextObjects2= [];
gdjs.Level_329Code.GDexitToMainMenuObjects1= [];
gdjs.Level_329Code.GDexitToMainMenuObjects2= [];
gdjs.Level_329Code.GDRestartObjects1= [];
gdjs.Level_329Code.GDRestartObjects2= [];
gdjs.Level_329Code.GDGreenObjects1= [];
gdjs.Level_329Code.GDGreenObjects2= [];
gdjs.Level_329Code.GDNewTextObjects1= [];
gdjs.Level_329Code.GDNewTextObjects2= [];

gdjs.Level_329Code.conditionTrue_0 = {val:false};
gdjs.Level_329Code.condition0IsTrue_0 = {val:false};
gdjs.Level_329Code.condition1IsTrue_0 = {val:false};
gdjs.Level_329Code.condition2IsTrue_0 = {val:false};


gdjs.Level_329Code.asyncCallback9651796 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_329Code.GDspawnBallObjects2);
{for(var i = 0, len = gdjs.Level_329Code.GDspawnBallObjects2.length ;i < len;++i) {
    gdjs.Level_329Code.GDspawnBallObjects2[i].activateBehavior("Physics2", true);
}
}{gdjs.evtsExt__DiscordRichPresence__UpdateRichPresence.func(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), "Hit somthing game", 0, 0, "", "", "", "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.window.setWindowTitle(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene) + " - Hit something");
}}
gdjs.Level_329Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Level_329Code.asyncCallback9651796(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDpauseObjects1Objects = Hashtable.newFrom({"pause": gdjs.Level_329Code.GDpauseObjects1});
gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDPauseBackgroundObjects1Objects = Hashtable.newFrom({"PauseBackground": gdjs.Level_329Code.GDPauseBackgroundObjects1});
gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDPausedTextObjects1Objects = Hashtable.newFrom({"PausedText": gdjs.Level_329Code.GDPausedTextObjects1});
gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDexitToMainMenuObjects1Objects = Hashtable.newFrom({"exitToMainMenu": gdjs.Level_329Code.GDexitToMainMenuObjects1});
gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDRestartObjects1Objects = Hashtable.newFrom({"Restart": gdjs.Level_329Code.GDRestartObjects1});
gdjs.Level_329Code.asyncCallback10258076 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
gdjs.Level_329Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_329Code.asyncCallback10258076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_329Code.asyncCallback10263084 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
gdjs.Level_329Code.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.Level_329Code.asyncCallback10263084(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDspawnBallObjects1Objects = Hashtable.newFrom({"spawnBall": gdjs.Level_329Code.GDspawnBallObjects1});
gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDbottomObjects1Objects = Hashtable.newFrom({"bottom": gdjs.Level_329Code.GDbottomObjects1});
gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.Level_329Code.GDBallObjects1});
gdjs.Level_329Code.asyncCallback9077140 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Level 9");
}}
gdjs.Level_329Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Level_329Code.asyncCallback9077140(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDleftWallObjects1Objects = Hashtable.newFrom({"leftWall": gdjs.Level_329Code.GDleftWallObjects1});
gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.Level_329Code.GDBallObjects1});
gdjs.Level_329Code.eventsList4 = function(runtimeScene) {

{


gdjs.Level_329Code.condition0IsTrue_0.val = false;
{
gdjs.Level_329Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_329Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Level_329Code.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Level_329Code.condition0IsTrue_0.val = false;
{
gdjs.Level_329Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Level_329Code.condition0IsTrue_0.val) {
gdjs.Level_329Code.GDpauseObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDpauseObjects1Objects, 1824, 18, "");
}{for(var i = 0, len = gdjs.Level_329Code.GDpauseObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDpauseObjects1[i].setScale(5);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.Level_329Code.GDpauseObjects1);

gdjs.Level_329Code.condition0IsTrue_0.val = false;
gdjs.Level_329Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_329Code.GDpauseObjects1.length;i<l;++i) {
    if ( gdjs.Level_329Code.GDpauseObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_329Code.condition0IsTrue_0.val = true;
        gdjs.Level_329Code.GDpauseObjects1[k] = gdjs.Level_329Code.GDpauseObjects1[i];
        ++k;
    }
}
gdjs.Level_329Code.GDpauseObjects1.length = k;}if ( gdjs.Level_329Code.condition0IsTrue_0.val ) {
{
gdjs.Level_329Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_329Code.condition1IsTrue_0.val) {
gdjs.Level_329Code.GDPauseBackgroundObjects1.length = 0;

gdjs.Level_329Code.GDPausedTextObjects1.length = 0;

gdjs.Level_329Code.GDRestartObjects1.length = 0;

gdjs.Level_329Code.GDexitToMainMenuObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDPauseBackgroundObjects1Objects, 548, 106, "");
}{for(var i = 0, len = gdjs.Level_329Code.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDPauseBackgroundObjects1[i].setHeight(805);
}
}{for(var i = 0, len = gdjs.Level_329Code.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDPauseBackgroundObjects1[i].setWidth(797);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDPausedTextObjects1Objects, 777, 187, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDexitToMainMenuObjects1Objects, 726, 678, "");
}{for(var i = 0, len = gdjs.Level_329Code.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDexitToMainMenuObjects1[i].setHeight(158);
}
}{for(var i = 0, len = gdjs.Level_329Code.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDexitToMainMenuObjects1[i].setWidth(418);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDRestartObjects1Objects, 748, 316, "");
}{for(var i = 0, len = gdjs.Level_329Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDRestartObjects1[i].setHeight(182);
}
}{for(var i = 0, len = gdjs.Level_329Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDRestartObjects1[i].setWidth(376);
}
}
{ //Subevents
gdjs.Level_329Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("exitToMainMenu"), gdjs.Level_329Code.GDexitToMainMenuObjects1);

gdjs.Level_329Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_329Code.GDexitToMainMenuObjects1.length;i<l;++i) {
    if ( gdjs.Level_329Code.GDexitToMainMenuObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_329Code.condition0IsTrue_0.val = true;
        gdjs.Level_329Code.GDexitToMainMenuObjects1[k] = gdjs.Level_329Code.GDexitToMainMenuObjects1[i];
        ++k;
    }
}
gdjs.Level_329Code.GDexitToMainMenuObjects1.length = k;}if (gdjs.Level_329Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Start menu");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Level_329Code.GDRestartObjects1);

gdjs.Level_329Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_329Code.GDRestartObjects1.length;i<l;++i) {
    if ( gdjs.Level_329Code.GDRestartObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_329Code.condition0IsTrue_0.val = true;
        gdjs.Level_329Code.GDRestartObjects1[k] = gdjs.Level_329Code.GDRestartObjects1[i];
        ++k;
    }
}
gdjs.Level_329Code.GDRestartObjects1.length = k;}if (gdjs.Level_329Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene));
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{


gdjs.Level_329Code.condition0IsTrue_0.val = false;
{
gdjs.Level_329Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if (gdjs.Level_329Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_329Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_329Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_329Code.GDBallObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDBallObjects1[i].activateBehavior("Physics2", false);
}
}{for(var i = 0, len = gdjs.Level_329Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDspawnBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{


gdjs.Level_329Code.condition0IsTrue_0.val = false;
{
gdjs.Level_329Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if (gdjs.Level_329Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_329Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_329Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_329Code.GDBallObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDBallObjects1[i].activateBehavior("Physics2", true);
}
}{for(var i = 0, len = gdjs.Level_329Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDspawnBallObjects1[i].activateBehavior("Physics2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pause"), gdjs.Level_329Code.GDpauseObjects1);

gdjs.Level_329Code.condition0IsTrue_0.val = false;
gdjs.Level_329Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_329Code.GDpauseObjects1.length;i<l;++i) {
    if ( gdjs.Level_329Code.GDpauseObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_329Code.condition0IsTrue_0.val = true;
        gdjs.Level_329Code.GDpauseObjects1[k] = gdjs.Level_329Code.GDpauseObjects1[i];
        ++k;
    }
}
gdjs.Level_329Code.GDpauseObjects1.length = k;}if ( gdjs.Level_329Code.condition0IsTrue_0.val ) {
{
gdjs.Level_329Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}
if (gdjs.Level_329Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("PauseBackground"), gdjs.Level_329Code.GDPauseBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("PausedText"), gdjs.Level_329Code.GDPausedTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.Level_329Code.GDRestartObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitToMainMenu"), gdjs.Level_329Code.GDexitToMainMenuObjects1);
{for(var i = 0, len = gdjs.Level_329Code.GDPauseBackgroundObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDPauseBackgroundObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_329Code.GDPausedTextObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDPausedTextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_329Code.GDexitToMainMenuObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDexitToMainMenuObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level_329Code.GDRestartObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDRestartObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Level_329Code.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Gravity"), gdjs.Level_329Code.GDGravityObjects1);

gdjs.Level_329Code.condition0IsTrue_0.val = false;
gdjs.Level_329Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_329Code.GDGravityObjects1.length;i<l;++i) {
    if ( gdjs.Level_329Code.GDGravityObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.Level_329Code.condition0IsTrue_0.val = true;
        gdjs.Level_329Code.GDGravityObjects1[k] = gdjs.Level_329Code.GDGravityObjects1[i];
        ++k;
    }
}
gdjs.Level_329Code.GDGravityObjects1.length = k;}if ( gdjs.Level_329Code.condition0IsTrue_0.val ) {
{
gdjs.Level_329Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_329Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_329Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_329Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDspawnBallObjects1[i].activateBehavior("Physics2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gravity"), gdjs.Level_329Code.GDGravityObjects1);

gdjs.Level_329Code.condition0IsTrue_0.val = false;
gdjs.Level_329Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Level_329Code.GDGravityObjects1.length;i<l;++i) {
    if ( !(gdjs.Level_329Code.GDGravityObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.Level_329Code.condition0IsTrue_0.val = true;
        gdjs.Level_329Code.GDGravityObjects1[k] = gdjs.Level_329Code.GDGravityObjects1[i];
        ++k;
    }
}
gdjs.Level_329Code.GDGravityObjects1.length = k;}if ( gdjs.Level_329Code.condition0IsTrue_0.val ) {
{
gdjs.Level_329Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_329Code.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("spawnBall"), gdjs.Level_329Code.GDspawnBallObjects1);
{for(var i = 0, len = gdjs.Level_329Code.GDspawnBallObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDspawnBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{


gdjs.Level_329Code.condition0IsTrue_0.val = false;
gdjs.Level_329Code.condition1IsTrue_0.val = false;
{
gdjs.Level_329Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Level_329Code.condition0IsTrue_0.val ) {
{
gdjs.Level_329Code.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}
if (gdjs.Level_329Code.condition1IsTrue_0.val) {
gdjs.Level_329Code.GDspawnBallObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDspawnBallObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_329Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("bottom"), gdjs.Level_329Code.GDbottomObjects1);

gdjs.Level_329Code.condition0IsTrue_0.val = false;
{
gdjs.Level_329Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDbottomObjects1Objects, "Physics2", gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDBallObjects1Objects, false);
}if (gdjs.Level_329Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Level_329Code.GDNewTextObjects1);
{for(var i = 0, len = gdjs.Level_329Code.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Level_329Code.GDNewTextObjects1[i].setString("Without touching the ground ");
}
}
{ //Subevents
gdjs.Level_329Code.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.Level_329Code.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("leftWall"), gdjs.Level_329Code.GDleftWallObjects1);

gdjs.Level_329Code.condition0IsTrue_0.val = false;
{
gdjs.Level_329Code.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDleftWallObjects1Objects, "Physics2", gdjs.Level_329Code.mapOfGDgdjs_46Level_95329Code_46GDBallObjects1Objects, false);
}if (gdjs.Level_329Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Level 10");
}}

}


};

gdjs.Level_329Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_329Code.GDleftWallObjects1.length = 0;
gdjs.Level_329Code.GDleftWallObjects2.length = 0;
gdjs.Level_329Code.GDrightWallObjects1.length = 0;
gdjs.Level_329Code.GDrightWallObjects2.length = 0;
gdjs.Level_329Code.GDbottomObjects1.length = 0;
gdjs.Level_329Code.GDbottomObjects2.length = 0;
gdjs.Level_329Code.GDBallObjects1.length = 0;
gdjs.Level_329Code.GDBallObjects2.length = 0;
gdjs.Level_329Code.GDspawnBallObjects1.length = 0;
gdjs.Level_329Code.GDspawnBallObjects2.length = 0;
gdjs.Level_329Code.GDGravityObjects1.length = 0;
gdjs.Level_329Code.GDGravityObjects2.length = 0;
gdjs.Level_329Code.GDmusicObjects1.length = 0;
gdjs.Level_329Code.GDmusicObjects2.length = 0;
gdjs.Level_329Code.GDgravityTextObjects1.length = 0;
gdjs.Level_329Code.GDgravityTextObjects2.length = 0;
gdjs.Level_329Code.GDfpsObjects1.length = 0;
gdjs.Level_329Code.GDfpsObjects2.length = 0;
gdjs.Level_329Code.GDpauseObjects1.length = 0;
gdjs.Level_329Code.GDpauseObjects2.length = 0;
gdjs.Level_329Code.GDPauseBackgroundObjects1.length = 0;
gdjs.Level_329Code.GDPauseBackgroundObjects2.length = 0;
gdjs.Level_329Code.GDPausedTextObjects1.length = 0;
gdjs.Level_329Code.GDPausedTextObjects2.length = 0;
gdjs.Level_329Code.GDexitToMainMenuObjects1.length = 0;
gdjs.Level_329Code.GDexitToMainMenuObjects2.length = 0;
gdjs.Level_329Code.GDRestartObjects1.length = 0;
gdjs.Level_329Code.GDRestartObjects2.length = 0;
gdjs.Level_329Code.GDGreenObjects1.length = 0;
gdjs.Level_329Code.GDGreenObjects2.length = 0;
gdjs.Level_329Code.GDNewTextObjects1.length = 0;
gdjs.Level_329Code.GDNewTextObjects2.length = 0;

gdjs.Level_329Code.eventsList4(runtimeScene);

return;

}

gdjs['Level_329Code'] = gdjs.Level_329Code;
